class AppConstants {
  static const String appName = 'shivnath_agency';

  static const String customerRole = 'customer';
  static const String franchiseRole = 'franchise';
  static const String adminRole = 'admin';

  static const String userSessionKey = 'logged_in_user';
  static const String selectedRoleKey = 'selected_role';
}