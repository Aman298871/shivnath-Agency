import '../../models/product_model.dart';

class ProductService {
  static const List<ProductModel> products = [
    ProductModel(
      id: 'p1',
      name: '250 ML Water Bottle',
      category: 'Water Bottle',
      size: '250 ML',
      price: 180,
      unit: 'Carton',
      image: '',
      stock: 120,
      description:
          'Pure packaged drinking water suitable for events, offices and daily use.',
    ),
    ProductModel(
      id: 'p2',
      name: '500 ML Water Bottle',
      category: 'Water Bottle',
      size: '500 ML',
      price: 210,
      unit: 'Carton',
      image: '',
      stock: 95,
      description:
          'Convenient packaged drinking water for daily use.',
    ),
    ProductModel(
      id: 'p3',
      name: '1 Litre Water Bottle',
      category: 'Water Bottle',
      size: '1 Litre',
      price: 220,
      unit: 'Carton',
      image: '',
      stock: 80,
      description:
          'Pure 1 litre packaged drinking water for home and travel.',
    ),
    ProductModel(
      id: 'p4',
      name: '2 Litre Water Bottle',
      category: 'Water Bottle',
      size: '2 Litre',
      price: 260,
      unit: 'Carton',
      image: '',
      stock: 55,
      description:
          'Large drinking water bottle suitable for family use.',
    ),
    ProductModel(
      id: 'p5',
      name: '5 Litre Water Jar',
      category: 'Water Jar',
      size: '5 Litre',
      price: 85,
      unit: 'Piece',
      image: '',
      stock: 65,
      description:
          '5 litre pure drinking water jar.',
    ),
    ProductModel(
      id: 'p6',
      name: '20 Litre Water Jar',
      category: 'Water Jar',
      size: '20 Litre',
      price: 55,
      unit: 'Piece',
      image: '',
      stock: 150,
      description:
          '20 litre water jar suitable for homes, offices and businesses.',
    ),
  ];
}