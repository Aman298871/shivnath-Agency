import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../models/user_model.dart';
import '../constants/app_constants.dart';

class SessionService {
  Future<void> saveRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.selectedRoleKey, role);
  }

  Future<String?> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.selectedRoleKey);
  }

  Future<void> saveUser(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      AppConstants.userSessionKey,
      jsonEncode(user.toMap()),
    );
  }

  Future<UserModel?> getUser() async {
    final prefs = await SharedPreferences.getInstance();

    final userJson = prefs.getString(AppConstants.userSessionKey);

    if (userJson == null) {
      return null;
    }

    try {
      final decoded = jsonDecode(userJson);

      return UserModel.fromMap(decoded);
    } catch (_) {
      return null;
    }
  }

  Future<bool> isLoggedIn() async {
    final user = await getUser();
    return user != null;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.remove(AppConstants.userSessionKey);
    await prefs.remove(AppConstants.selectedRoleKey);
  }
}