import 'package:flutter/material.dart';

class AdminDashboardScreen
    extends StatelessWidget {
  final VoidCallback? onOpenLeads;
  final VoidCallback? onOpenFollowups;

  const AdminDashboardScreen({
    super.key,
    this.onOpenLeads,
    this.onOpenFollowups,
  });

  static const List<Map<String, dynamic>>
      stats = [
    {
      'title': 'Total Leads',
      'value': '245',
      'change': '+12.5%',
      'icon': Icons.people_alt_outlined,
    },
    {
      'title': 'Hot Leads',
      'value': '38',
      'change': '+8.2%',
      'icon': Icons.local_fire_department_outlined,
    },
    {
      'title': 'Follow-ups Today',
      'value': '24',
      'change': '6 pending',
      'icon': Icons.calendar_month_outlined,
    },
    {
      'title': 'Confirmed Franchises',
      'value': '12',
      'change': '+3 this month',
      'icon': Icons.storefront_outlined,
    },
  ];

  static const List<Map<String, dynamic>>
      pipeline = [
    {
      'name': 'New Lead',
      'value': 45,
    },
    {
      'name': 'Contacted',
      'value': 38,
    },
    {
      'name': 'Follow-up',
      'value': 52,
    },
    {
      'name': 'Interested',
      'value': 31,
    },
    {
      'name': 'Site Visit',
      'value': 15,
    },
    {
      'name': 'Agreement',
      'value': 8,
    },
    {
      'name': 'Confirmed',
      'value': 12,
    },
  ];

  static const List<Map<String, String>>
      followups = [
    {
      'time': '10:30 AM',
      'name': 'Rahul Sharma',
      'text':
          'Call regarding franchise investment',
    },
    {
      'time': '12:00 PM',
      'name': 'Amit Verma',
      'text':
          'Send franchise brochure',
    },
    {
      'time': '03:30 PM',
      'name': 'Priya Singh',
      'text':
          'Site visit confirmation',
    },
    {
      'time': '05:00 PM',
      'name': 'Suresh Gupta',
      'text':
          'Second follow-up call',
    },
  ];

  static const List<Map<String, String>>
      leads = [
    {
      'name': 'Rahul Sharma',
      'phone':
          '+91 98765 43210',
      'city': 'Raipur',
      'budget':
          '₹15-20 Lakh',
      'score': 'Hot',
      'status':
          'Interested',
    },
    {
      'name': 'Amit Verma',
      'phone':
          '+91 98261 12345',
      'city': 'Bilaspur',
      'budget':
          '₹10-15 Lakh',
      'score': 'Warm',
      'status':
          'Follow-up',
    },
    {
      'name': 'Priya Singh',
      'phone':
          '+91 97555 44556',
      'city': 'Durg',
      'budget':
          '₹20-25 Lakh',
      'score': 'Hot',
      'status':
          'Site Visit',
    },
    {
      'name': 'Suresh Gupta',
      'phone':
          '+91 93012 33445',
      'city':
          'Rajnandgaon',
      'budget':
          '₹8-10 Lakh',
      'score': 'Cold',
      'status':
          'Contacted',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        final desktop =
            constraints.maxWidth >= 900;

        return Container(
          color:
              const Color(
            0xFFF5F7FB,
          ),
          child:
              SingleChildScrollView(
            padding:
                EdgeInsets.all(
              desktop ? 28 : 16,
            ),
            child:
                ConstrainedBox(
              constraints:
                  const BoxConstraints(
                maxWidth: 1300,
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment
                        .start,
                children: [
                  _header(
                    desktop,
                  ),

                  const SizedBox(
                    height: 24,
                  ),

                  _statsSection(
                    desktop,
                  ),

                  const SizedBox(
                    height: 22,
                  ),

                  if (desktop)
                    Row(
                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,
                      children: [
                        Expanded(
                          child:
                              _pipelineCard(),
                        ),
                        const SizedBox(
                          width: 18,
                        ),
                        Expanded(
                          child:
                              _followupCard(),
                        ),
                      ],
                    )
                  else ...[
                    _pipelineCard(),
                    const SizedBox(
                      height: 16,
                    ),
                    _followupCard(),
                  ],

                  const SizedBox(
                    height: 22,
                  ),

                  _recentLeadsCard(
                    desktop,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _header(
  bool desktop,
) {
  return const Column(
    crossAxisAlignment:
        CrossAxisAlignment.start,
    children: [
      Text(
        'Dashboard',
        style: TextStyle(
          fontSize: 28,
          fontWeight:
              FontWeight.w800,
          color:
              Color(
            0xFF111827,
          ),
        ),
      ),
      SizedBox(
        height: 5,
      ),
      Text(
        'Overview of your franchise business',
        style: TextStyle(
          color:
              Color(
            0xFF64748B,
          ),
          fontSize: 13,
        ),
      ),
    ],
  );
}
  Widget _statsSection(
    bool desktop,
  ) {
    if (desktop) {
      return Row(
        children:
            List.generate(
          stats.length,
          (index) {
            return Expanded(
              child: Padding(
                padding:
                    EdgeInsets.only(
                  right:
                      index ==
                              stats.length -
                                  1
                          ? 0
                          : 14,
                ),
                child:
                    _StatCard(
                  item:
                      stats[index],
                ),
              ),
            );
          },
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics:
          const NeverScrollableScrollPhysics(),
      gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.35,
      ),
      itemCount:
          stats.length,
      itemBuilder:
          (_, index) {
        return _StatCard(
          item:
              stats[index],
        );
      },
    );
  }

  Widget _pipelineCard() {
    return _card(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          _cardHeader(
            title:
                'Lead Pipeline',
            subtitle:
                'Current lead distribution',
            button:
                'View All',
            onTap:
                onOpenLeads,
          ),

          const SizedBox(
            height: 20,
          ),

          ...pipeline.map(
            (item) {
              final value =
                  item['value']
                      as int;

              final progress =
                  (value * 1.7 /
                          100)
                      .clamp(
                0.0,
                1.0,
              );

              return Padding(
                padding:
                    const EdgeInsets
                        .only(
                  bottom: 15,
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child:
                              Text(
                            item['name']
                                .toString(),
                            style:
                                const TextStyle(
                              fontSize:
                                  12,
                              fontWeight:
                                  FontWeight
                                      .w600,
                            ),
                          ),
                        ),
                        Text(
                          '$value',
                          style:
                              const TextStyle(
                            fontWeight:
                                FontWeight
                                    .w800,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 7,
                    ),
                    ClipRRect(
                      borderRadius:
                          BorderRadius
                              .circular(
                        10,
                      ),
                      child:
                          LinearProgressIndicator(
                        value:
                            progress,
                        minHeight:
                            7,
                        backgroundColor:
                            const Color(
                          0xFFEFF1F5,
                        ),
                        valueColor:
                            const AlwaysStoppedAnimation(
                          Color(
                            0xFF4F46E5,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _followupCard() {
    return _card(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          _cardHeader(
            title:
                "Today's Follow-ups",
            subtitle:
                'Upcoming actions',
            button:
                'View All',
            onTap:
                onOpenFollowups,
          ),

          const SizedBox(
            height: 14,
          ),

          ...followups.map(
            (item) {
              return Container(
                padding:
                    const EdgeInsets
                        .symmetric(
                  vertical: 12,
                ),
                decoration:
                    const BoxDecoration(
                  border: Border(
                    bottom:
                        BorderSide(
                      color:
                          Color(
                        0xFFF1F5F9,
                      ),
                    ),
                  ),
                ),
                child: Row(
                  crossAxisAlignment:
                      CrossAxisAlignment
                          .start,
                  children: [
                    SizedBox(
                      width: 72,
                      child: Text(
                        item['time']!,
                        style:
                            const TextStyle(
                          fontSize:
                              11,
                          color:
                              Color(
                            0xFF4F46E5,
                          ),
                          fontWeight:
                              FontWeight
                                  .w700,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment
                                .start,
                        children: [
                          Text(
                            item['name']!,
                            style:
                                const TextStyle(
                              fontSize:
                                  12,
                              fontWeight:
                                  FontWeight
                                      .w700,
                            ),
                          ),
                          const SizedBox(
                            height: 3,
                          ),
                          Text(
                            item['text']!,
                            style:
                                const TextStyle(
                              fontSize:
                                  11,
                              color:
                                  Color(
                                0xFF64748B,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _recentLeadsCard(
    bool desktop,
  ) {
    return _card(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          _cardHeader(
            title:
                'Recent Leads',
            subtitle:
                'Latest franchise enquiries',
            button:
                'View All',
            onTap:
                onOpenLeads,
          ),

          const SizedBox(
            height: 18,
          ),

          if (desktop)
            _leadsTable()
          else
            ...leads.map(
              _mobileLeadCard,
            ),
        ],
      ),
    );
  }

  Widget _leadsTable() {
    return Column(
      children: [
        Container(
          padding:
              const EdgeInsets
                  .symmetric(
            vertical: 12,
          ),
          child:
              const Row(
            children: [
              Expanded(
                flex: 2,
                child:
                    Text(
                  'LEAD',
                  style:
                      _headerTextStyle,
                ),
              ),
              Expanded(
                child:
                    Text(
                  'CITY',
                  style:
                      _headerTextStyle,
                ),
              ),
              Expanded(
                flex: 2,
                child:
                    Text(
                  'INVESTMENT BUDGET',
                  style:
                      _headerTextStyle,
                ),
              ),
              Expanded(
                child:
                    Text(
                  'SCORE',
                  style:
                      _headerTextStyle,
                ),
              ),
              Expanded(
                child:
                    Text(
                  'STATUS',
                  style:
                      _headerTextStyle,
                ),
              ),
            ],
          ),
        ),

        const Divider(
          height: 1,
        ),

        ...leads.map(
          (lead) {
            return Container(
              padding:
                  const EdgeInsets
                      .symmetric(
                vertical: 14,
              ),
              decoration:
                  const BoxDecoration(
                border: Border(
                  bottom:
                      BorderSide(
                    color:
                        Color(
                      0xFFF1F5F9,
                    ),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child:
                        Column(
                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,
                      children: [
                        Text(
                          lead[
                              'name']!,
                          style:
                              const TextStyle(
                            fontSize:
                                12,
                            fontWeight:
                                FontWeight
                                    .w700,
                          ),
                        ),
                        const SizedBox(
                          height: 3,
                        ),
                        Text(
                          lead[
                              'phone']!,
                          style:
                              const TextStyle(
                            fontSize:
                                10,
                            color:
                                Color(
                              0xFF94A3B8,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child:
                        Text(
                      lead[
                          'city']!,
                      style:
                          const TextStyle(
                        fontSize: 11,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child:
                        Text(
                      lead[
                          'budget']!,
                      style:
                          const TextStyle(
                        fontSize: 11,
                      ),
                    ),
                  ),
                  Expanded(
                    child:
                        Align(
                      alignment:
                          Alignment
                              .centerLeft,
                      child:
                          _scoreBadge(
                        lead[
                            'score']!,
                      ),
                    ),
                  ),
                  Expanded(
                    child:
                        Text(
                      lead[
                          'status']!,
                      style:
                          const TextStyle(
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _mobileLeadCard(
    Map<String, String> lead,
  ) {
    return Container(
      margin:
          const EdgeInsets.only(
        bottom: 10,
      ),
      padding:
          const EdgeInsets.all(
        14,
      ),
      decoration:
          BoxDecoration(
        color:
            const Color(
          0xFFF8FAFC,
        ),
        borderRadius:
            BorderRadius.circular(
          10,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  lead['name']!,
                  style:
                      const TextStyle(
                    fontWeight:
                        FontWeight
                            .w700,
                  ),
                ),
              ),
              _scoreBadge(
                lead['score']!,
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
            lead['phone']!,
            style:
                const TextStyle(
              fontSize: 11,
              color:
                  Color(
                0xFF64748B,
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            '${lead['city']} • ${lead['budget']}',
            style:
                const TextStyle(
              fontSize: 11,
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
            'Status: ${lead['status']}',
            style:
                const TextStyle(
              fontSize: 11,
              color:
                  Color(
                0xFF64748B,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _scoreBadge(
    String score,
  ) {
    Color bg;
    Color fg;

    if (score == 'Hot') {
      bg =
          const Color(
        0xFFFEF2F2,
      );
      fg =
          const Color(
        0xFFDC2626,
      );
    } else if (score ==
        'Warm') {
      bg =
          const Color(
        0xFFFFF7ED,
      );
      fg =
          const Color(
        0xFFEA580C,
      );
    } else {
      bg =
          const Color(
        0xFFF1F5F9,
      );
      fg =
          const Color(
        0xFF64748B,
      );
    }

    return Container(
      padding:
          const EdgeInsets
              .symmetric(
        horizontal: 9,
        vertical: 5,
      ),
      decoration:
          BoxDecoration(
        color: bg,
        borderRadius:
            BorderRadius.circular(
          20,
        ),
      ),
      child: Text(
        score,
        style:
            TextStyle(
          color: fg,
          fontSize: 10,
          fontWeight:
              FontWeight.w700,
        ),
      ),
    );
  }

  Widget _cardHeader({
    required String title,
    required String subtitle,
    required String button,
    VoidCallback? onTap,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment
                    .start,
            children: [
              Text(
                title,
                style:
                    const TextStyle(
                  fontSize: 16,
                  fontWeight:
                      FontWeight
                          .w800,
                ),
              ),
              const SizedBox(
                height: 3,
              ),
              Text(
                subtitle,
                style:
                    const TextStyle(
                  fontSize: 11,
                  color:
                      Color(
                    0xFF94A3B8,
                  ),
                ),
              ),
            ],
          ),
        ),
        TextButton(
          onPressed: onTap,
          child: Text(
            button,
          ),
        ),
      ],
    );
  }

  Widget _card({
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(
        20,
      ),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(
          14,
        ),
        border: Border.all(
          color:
              const Color(
            0xFFE5E7EB,
          ),
        ),
      ),
      child: child,
    );
  }
}

class _StatCard
    extends StatelessWidget {
  final Map<String, dynamic> item;

  const _StatCard({
    required this.item,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      padding:
          const EdgeInsets.all(
        18,
      ),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(
          14,
        ),
        border: Border.all(
          color:
              const Color(
            0xFFE5E7EB,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
              children: [
                Text(
                  item['title']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 11,
                    color:
                        Color(
                      0xFF64748B,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 7,
                ),
                Text(
                  item['value']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 24,
                    fontWeight:
                        FontWeight
                            .w800,
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  item['change']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 10,
                    color:
                        Color(
                      0xFF16A34A,
                    ),
                    fontWeight:
                        FontWeight
                            .w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 44,
            height: 44,
            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFEEF2FF,
              ),
              borderRadius:
                  BorderRadius
                      .circular(
                12,
              ),
            ),
            child: Icon(
              item['icon']
                  as IconData,
              color:
                  const Color(
                0xFF4F46E5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const TextStyle
    _headerTextStyle =
    TextStyle(
  fontSize: 9,
  fontWeight:
      FontWeight.w700,
  color:
      Color(0xFF64748B),
  letterSpacing: 0.4,
);