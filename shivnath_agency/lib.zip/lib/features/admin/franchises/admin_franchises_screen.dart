import 'package:flutter/material.dart';
import '../../../core/widgets/app_toast.dart';

class AdminFranchisesScreen extends StatefulWidget {
  const AdminFranchisesScreen({super.key});

  @override
  State<AdminFranchisesScreen> createState() =>
      _AdminFranchisesScreenState();
}

class _AdminFranchisesScreenState
    extends State<AdminFranchisesScreen> {
  final List<Map<String, dynamic>> franchises = [
    {
      'id': 1,
      'owner': 'Rahul Sharma',
      'phone': '9876543210',
      'email': 'rahul@example.com',
      'city': 'Raipur',
      'territory': 'Raipur North',
      'gst': '22ABCDE1234F1Z5',
      'pan': 'ABCDE1234F',
      'aadhaar': 'XXXX XXXX 4587',
      'securityDeposit': 250000,
      'commission': '12%',
      'status': 'Active',
      'renewalDate': '2027-09-03',
      'agreement': 'Uploaded',
    },
    {
      'id': 2,
      'owner': 'Amit Verma',
      'phone': '9826112345',
      'email': 'amit@example.com',
      'city': 'Bilaspur',
      'territory': 'Bilaspur City',
      'gst': '22PQRSX5678G1Z2',
      'pan': 'PQRSX5678G',
      'aadhaar': 'XXXX XXXX 7741',
      'securityDeposit': 200000,
      'commission': '10%',
      'status': 'Pending',
      'renewalDate': '2027-10-12',
      'agreement': 'Pending',
    },
    {
      'id': 3,
      'owner': 'Priya Singh',
      'phone': '9755544556',
      'email': 'priya@example.com',
      'city': 'Durg',
      'territory': 'Durg-Bhilai',
      'gst': '22LMNOP2468K1Z8',
      'pan': 'LMNOP2468K',
      'aadhaar': 'XXXX XXXX 2219',
      'securityDeposit': 300000,
      'commission': '15%',
      'status': 'Active',
      'renewalDate': '2027-08-25',
      'agreement': 'Uploaded',
    },
  ];

  String search = '';
  String statusFilter = 'All';

  List<Map<String, dynamic>> get filtered {
    final keyword = search.trim().toLowerCase();

    return franchises.where((item) {
      final matchesSearch =
          keyword.isEmpty ||
          item['owner']
              .toString()
              .toLowerCase()
              .contains(keyword) ||
          item['phone'].toString().contains(keyword) ||
          item['city']
              .toString()
              .toLowerCase()
              .contains(keyword) ||
          item['territory']
              .toString()
              .toLowerCase()
              .contains(keyword);

      final matchesStatus =
          statusFilter == 'All' ||
          item['status'] == statusFilter;

      return matchesSearch && matchesStatus;
    }).toList();
  }

  int get totalDeposit {
    return franchises.fold<int>(
      0,
      (sum, item) =>
          sum +
          ((item['securityDeposit'] as num?)
                  ?.toInt() ??
              0),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop =
            constraints.maxWidth >= 900;

        return Container(
          width: double.infinity,
          height: double.infinity,
          color: const Color(0xFFF5F7FB),
          child: SingleChildScrollView(
            padding: EdgeInsets.all(
              desktop ? 28 : 16,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints:
                    const BoxConstraints(
                  maxWidth: 1350,
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    _header(desktop),
                    const SizedBox(height: 22),
                    _stats(desktop),
                    const SizedBox(height: 20),
                    _toolbar(desktop),
                    const SizedBox(height: 14),
                    desktop
                        ? _table()
                        : _mobileList(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _header(bool desktop) {
    return Row(
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                'Franchises',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight:
                      FontWeight.w800,
                  color:
                      Color(0xFF111827),
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Manage approved franchise partners and territories',
                style: TextStyle(
                  color:
                      Color(0xFF64748B),
                ),
              ),
            ],
          ),
        ),
        if (desktop)
          SizedBox(
            width: 180,
            height: 44,
            child:
                ElevatedButton.icon(
              style:
                  ElevatedButton
                      .styleFrom(
                minimumSize:
                    const Size(
                  180,
                  44,
                ),
                maximumSize:
                    const Size(
                  180,
                  44,
                ),
              ),
              onPressed: () {
                _openForm();
              },
              icon: const Icon(
                Icons.add_rounded,
                size: 18,
              ),
              label: const Text(
                'Add Franchise',
                maxLines: 1,
                softWrap: false,
              ),
            ),
          ),
      ],
    );
  }

  Widget _stats(bool desktop) {
    final data = [
      [
        'Total Franchises',
        '${franchises.length}',
      ],
      [
        'Active',
        '${franchises.where((e) => e['status'] == 'Active').length}',
      ],
      [
        'Pending Approval',
        '${franchises.where((e) => e['status'] == 'Pending').length}',
      ],
      [
        'Security Deposit',
        '₹${(totalDeposit / 100000).toStringAsFixed(1)}L',
      ],
    ];

    if (desktop) {
      return Row(
        children: List.generate(
          data.length,
          (index) => Expanded(
            child: Padding(
              padding:
                  EdgeInsets.only(
                right:
                    index ==
                            data.length -
                                1
                        ? 0
                        : 14,
              ),
              child: _MiniStat(
                title:
                    data[index][0],
                value:
                    data[index][1],
              ),
            ),
          ),
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics:
          const NeverScrollableScrollPhysics(),
      itemCount: data.length,
      gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.7,
      ),
      itemBuilder: (_, index) {
        return _MiniStat(
          title: data[index][0],
          value: data[index][1],
        );
      },
    );
  }

  Widget _toolbar(bool desktop) {
    return Container(
      padding:
          const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color:
              const Color(0xFFE5E7EB),
        ),
      ),
      child: desktop
          ? Row(
              children: [
                Expanded(
                  child:
                      _searchBox(),
                ),
                const SizedBox(
                  width: 14,
                ),
                SizedBox(
                  width: 190,
                  child:
                      _statusFilter(),
                ),
              ],
            )
          : Column(
              children: [
                _searchBox(),
                const SizedBox(
                  height: 10,
                ),
                _statusFilter(),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  width:
                      double.infinity,
                  height: 44,
                  child:
                      ElevatedButton.icon(
                    onPressed: () {
                      _openForm();
                    },
                    icon:
                        const Icon(
                      Icons.add,
                    ),
                    label:
                        const Text(
                      'Add Franchise',
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _searchBox() {
    return TextField(
      onChanged: (value) {
        setState(() {
          search = value;
        });
      },
      decoration:
          const InputDecoration(
        hintText:
            'Search owner, phone, city or territory...',
        prefixIcon:
            Icon(Icons.search),
      ),
    );
  }

  Widget _statusFilter() {
    return DropdownButtonFormField<
        String>(
      value: statusFilter,
      decoration:
          const InputDecoration(
        labelText: 'Status',
      ),
      items: const [
        DropdownMenuItem(
          value: 'All',
          child:
              Text('All Status'),
        ),
        DropdownMenuItem(
          value: 'Active',
          child: Text('Active'),
        ),
        DropdownMenuItem(
          value: 'Pending',
          child: Text('Pending'),
        ),
        DropdownMenuItem(
          value: 'Inactive',
          child: Text('Inactive'),
        ),
        DropdownMenuItem(
          value: 'Suspended',
          child: Text('Suspended'),
        ),
        DropdownMenuItem(
  value: 'Rejected',
  child: Text('Rejected'),
),
      ],
      onChanged: (value) {
        setState(() {
          statusFilter =
              value ?? 'All';
        });
      },
    );
  }

  Widget _table() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color:
              const Color(0xFFE5E7EB),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding:
                const EdgeInsets.all(
              15,
            ),
            color:
                const Color(
              0xFFF8FAFC,
            ),
            child: const Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'FRANCHISE OWNER',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  child: Text(
                    'TERRITORY',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'GST',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  child: Text(
                    'DEPOSIT',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  child: Text(
                    'COMMISSION',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  child: Text(
                    'AGREEMENT',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  child: Text(
                    'STATUS',
                    style:
                        _headerStyle,
                  ),
                ),
                Expanded(
                  child: Text(
                    'RENEWAL',
                    style:
                        _headerStyle,
                  ),
                ),
                SizedBox(
                  width: 200,
                  child: Text(
                    'ACTIONS',
                    style:
                        _headerStyle,
                  ),
                ),
              ],
            ),
          ),
          if (filtered.isEmpty)
            const Padding(
              padding:
                  EdgeInsets.symmetric(
                vertical: 50,
              ),
              child: Text(
                'No franchise found.',
              ),
            )
          else
            ...filtered.map(
              _desktopRow,
            ),
        ],
      ),
    );
  }

  Widget _desktopRow(
    Map<String, dynamic> item,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 15,
        vertical: 14,
      ),
      decoration:
          const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color:
                Color(
              0xFFF1F5F9,
            ),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  item['owner']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w700,
                  ),
                ),
                Text(
                  item['phone']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 9,
                    color:
                        Color(
                      0xFF94A3B8,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Text(
              item['territory']
                  .toString(),
              style:
                  const TextStyle(
                fontSize: 10,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              item['gst'].toString(),
              style:
                  const TextStyle(
                fontSize: 9,
              ),
            ),
          ),
          Expanded(
            child: Text(
              '₹${item['securityDeposit']}',
              style:
                  const TextStyle(
                fontSize: 10,
              ),
            ),
          ),
          Expanded(
            child: Text(
              item['commission']
                  .toString(),
            ),
          ),
          Expanded(
            child: _badge(
              item['agreement']
                  .toString(),
            ),
          ),
          Expanded(
            child: _badge(
              item['status']
                  .toString(),
            ),
          ),
          Expanded(
            child: Text(
              item['renewalDate']
                  .toString(),
              style:
                  const TextStyle(
                fontSize: 9,
              ),
            ),
          ),
          SizedBox(
            width: 200,
            child: Row(
  children: [
    IconButton(
      tooltip: 'View Franchise',
      onPressed: () {
        _view(item);
      },
      icon: const Icon(
        Icons.visibility_outlined,
        size: 17,
      ),
    ),

    // APPROVE / REJECT ONLY FOR PENDING FRANCHISE
    if (item['status'] == 'Pending') ...[
      IconButton(
        tooltip: 'Approve Franchise',
        onPressed: () {
          _approveFranchise(item);
        },
        icon: const Icon(
          Icons.check_circle_outline,
          color: Color(0xFF16A34A),
          size: 18,
        ),
      ),
      IconButton(
        tooltip: 'Reject Franchise',
        onPressed: () {
          _rejectFranchise(item);
        },
        icon: const Icon(
          Icons.cancel_outlined,
          color: Color(0xFFDC2626),
          size: 18,
        ),
      ),
    ],

    IconButton(
      tooltip: 'Edit Franchise',
      onPressed: () {
        _openForm(
          item: item,
        );
      },
      icon: const Icon(
        Icons.edit_outlined,
        size: 17,
      ),
    ),

    IconButton(
      tooltip: 'Delete Franchise',
      onPressed: () {
        _delete(item);
      },
      icon: const Icon(
        Icons.delete_outline,
        color: Colors.red,
        size: 17,
      ),
    ),
  ],
),
          ),
        ],
      ),
    );
  }

  Widget _mobileList() {
    return Column(
      children:
          filtered.map((item) {
        return Container(
          width: double.infinity,
          margin:
              const EdgeInsets.only(
            bottom: 12,
          ),
          padding:
              const EdgeInsets.all(
            15,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius:
                BorderRadius.circular(
              14,
            ),
            border: Border.all(
              color:
                  const Color(
                0xFFE5E7EB,
              ),
            ),
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      item['owner']
                          .toString(),
                      style:
                          const TextStyle(
                        fontWeight:
                            FontWeight.w700,
                      ),
                    ),
                  ),
                  _badge(
                    item['status']
                        .toString(),
                  ),
                ],
              ),
              const SizedBox(
                height: 8,
              ),
              Text(
                '${item['phone']} • ${item['city']}',
              ),
              const SizedBox(
                height: 5,
              ),
              Text(
                'Territory: ${item['territory']}',
              ),
              const SizedBox(
                height: 5,
              ),
              Text(
                'Deposit: ₹${item['securityDeposit']}',
              ),
              Wrap(
  alignment: WrapAlignment.end,
  spacing: 4,
  children: [
    IconButton(
      tooltip: 'View',
      onPressed: () {
        _view(item);
      },
      icon: const Icon(
        Icons.visibility_outlined,
      ),
    ),

    if (item['status'] == 'Pending') ...[
      IconButton(
        tooltip: 'Approve',
        onPressed: () {
          _approveFranchise(item);
        },
        icon: const Icon(
          Icons.check_circle_outline,
          color: Color(0xFF16A34A),
        ),
      ),
      IconButton(
        tooltip: 'Reject',
        onPressed: () {
          _rejectFranchise(item);
        },
        icon: const Icon(
          Icons.cancel_outlined,
          color: Color(0xFFDC2626),
        ),
      ),
    ],

    IconButton(
      tooltip: 'Edit',
      onPressed: () {
        _openForm(
          item: item,
        );
      },
      icon: const Icon(
        Icons.edit_outlined,
      ),
    ),

    IconButton(
      tooltip: 'Delete',
      onPressed: () {
        _delete(item);
      },
      icon: const Icon(
        Icons.delete_outline,
        color: Colors.red,
      ),
    ),
  ],
),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _badge(String value) {
    Color bg =
        const Color(
      0xFFEEF2FF,
    );
    Color fg =
        const Color(
      0xFF4F46E5,
    );

    if (value == 'Active' ||
        value == 'Uploaded') {
      bg =
          const Color(
        0xFFECFDF5,
      );
      fg =
          const Color(
        0xFF16A34A,
      );
    } else if (value ==
        'Pending') {
      bg =
          const Color(
        0xFFFFFBEB,
      );
      fg =
          const Color(
        0xFFD97706,
      );
    } else if (value ==
            'Inactive' ||
        value == 'Suspended'||
    value == 'Rejected') {
      bg =
          const Color(
        0xFFFEF2F2,
      );
      fg =
          const Color(
        0xFFDC2626,
      );
    }

    return Align(
      alignment:
          Alignment.centerLeft,
      child: Container(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 8,
          vertical: 5,
        ),
        decoration: BoxDecoration(
          color: bg,
          borderRadius:
              BorderRadius.circular(
            20,
          ),
        ),
        child: Text(
          value,
          style: TextStyle(
            fontSize: 9,
            color: fg,
            fontWeight:
                FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Future<void> _openForm({
    Map<String, dynamic>? item,
  }) async {
    final editing =
        item != null;

    final owner =
        TextEditingController(
      text:
          item?['owner'] ?? '',
    );
    final phone =
        TextEditingController(
      text:
          item?['phone'] ?? '',
    );
    final email =
        TextEditingController(
      text:
          item?['email'] ?? '',
    );
    final city =
        TextEditingController(
      text:
          item?['city'] ?? '',
    );
    final territory =
        TextEditingController(
      text:
          item?['territory'] ?? '',
    );
    final gst =
        TextEditingController(
      text:
          item?['gst'] ?? '',
    );
    final pan =
        TextEditingController(
      text:
          item?['pan'] ?? '',
    );
    final aadhaar =
        TextEditingController(
      text:
          item?['aadhaar'] ?? '',
    );
    final deposit =
        TextEditingController(
      text:
          item?['securityDeposit']
                  ?.toString() ??
              '',
    );
    final commission =
        TextEditingController(
      text:
          item?['commission'] ?? '',
    );
    final renewal =
        TextEditingController(
      text:
          item?['renewalDate'] ?? '',
    );

    String status =
        item?['status'] ??
            'Pending';
    String agreement =
        item?['agreement'] ??
            'Pending';

    bool saved = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (
        dialogContext,
      ) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            final desktop =
                MediaQuery.of(
                      context,
                    ).size.width >=
                    900;

            return Dialog(
              backgroundColor:
                  Colors.transparent,
              insetPadding:
                  EdgeInsets.symmetric(
                horizontal:
                    desktop ? 70 : 14,
                vertical:
                    desktop ? 28 : 16,
              ),
              child:
                  ConstrainedBox(
                constraints:
                    BoxConstraints(
                  maxWidth:
                      desktop
                          ? 920
                          : 600,
                  maxHeight:
                      MediaQuery.of(
                            context,
                          ).size.height *
                          .9,
                ),
                child: Container(
                  decoration:
                      BoxDecoration(
                    color:
                        const Color(
                      0xFFF8FAFC,
                    ),
                    borderRadius:
                        BorderRadius
                            .circular(
                      18,
                    ),
                    boxShadow:
                        const [
                      BoxShadow(
                        color:
                            Color(
                          0x22000000,
                        ),
                        blurRadius:
                            28,
                        offset:
                            Offset(
                          0,
                          12,
                        ),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      _formHeader(
                        title: editing
                            ? 'Edit Franchise'
                            : 'Add New Franchise',
                        subtitle:
                            'Manage partner, territory and agreement information',
                        icon:
                            Icons
                                .storefront_outlined,
                        onClose: () {
                          Navigator.pop(
                            dialogContext,
                          );
                        },
                      ),

                      Expanded(
                        child:
                            SingleChildScrollView(
                          padding:
                              EdgeInsets.all(
                            desktop
                                ? 22
                                : 16,
                          ),
                          child:
                              LayoutBuilder(
                            builder: (
                              context,
                              constraints,
                            ) {
                              final twoColumns =
                                  constraints
                                          .maxWidth >=
                                      700;

                              return Column(
                                children: [
                                  _formSection(
                                    title:
                                        'Owner Information',
                                    subtitle:
                                        'Primary franchise contact details',
                                    icon:
                                        Icons
                                            .person_outline,
                                    child:
                                        _formGrid(
                                      twoColumns,
                                      [
                                        _formField(
                                          owner,
                                          'Owner Name',
                                          Icons
                                              .person_outline,
                                          requiredField:
                                              true,
                                        ),
                                        _formField(
                                          phone,
                                          'Phone',
                                          Icons
                                              .phone_outlined,
                                          requiredField:
                                              true,
                                          keyboardType:
                                              TextInputType
                                                  .phone,
                                        ),
                                        _formField(
                                          email,
                                          'Email',
                                          Icons
                                              .email_outlined,
                                        ),
                                        _formField(
                                          city,
                                          'City',
                                          Icons
                                              .location_city_outlined,
                                          requiredField:
                                              true,
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 18,
                                  ),

                                  _formSection(
                                    title:
                                        'Business Details',
                                    subtitle:
                                        'Territory and legal information',
                                    icon:
                                        Icons
                                            .business_center_outlined,
                                    child:
                                        _formGrid(
                                      twoColumns,
                                      [
                                        _formField(
                                          territory,
                                          'Territory',
                                          Icons
                                              .map_outlined,
                                        ),
                                        _formField(
                                          gst,
                                          'GST Number',
                                          Icons
                                              .receipt_long_outlined,
                                        ),
                                        _formField(
                                          pan,
                                          'PAN',
                                          Icons
                                              .badge_outlined,
                                        ),
                                        _formField(
                                          aadhaar,
                                          'Aadhaar',
                                          Icons
                                              .credit_card_outlined,
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 18,
                                  ),

                                  _formSection(
                                    title:
                                        'Commercial & Agreement',
                                    subtitle:
                                        'Deposit, commission and agreement status',
                                    icon:
                                        Icons
                                            .handshake_outlined,
                                    child:
                                        _formGrid(
                                      twoColumns,
                                      [
                                        _formField(
                                          deposit,
                                          'Security Deposit',
                                          Icons
                                              .currency_rupee,
                                          keyboardType:
                                              TextInputType
                                                  .number,
                                        ),
                                        _formField(
                                          commission,
                                          'Commission',
                                          Icons
                                              .percent_outlined,
                                        ),
                                        _formField(
                                          renewal,
                                          'Renewal Date',
                                          Icons
                                              .calendar_today_outlined,
                                        ),
                                        _formDropdown(
                                          label:
                                              'Status',
                                          value:
                                              status,
                                          items:
                                              const [
                                            'Active',
                                            'Pending',
                                            'Inactive',
                                            'Suspended',
                                            'Rejected',
                                          ],
                                          onChanged:
                                              (
                                            value,
                                          ) {
                                            setDialogState(
                                              () {
                                                status =
                                                    value ??
                                                        status;
                                              },
                                            );
                                          },
                                        ),
                                        _formDropdown(
                                          label:
                                              'Agreement',
                                          value:
                                              agreement,
                                          items:
                                              const [
                                            'Uploaded',
                                            'Pending',
                                          ],
                                          onChanged:
                                              (
                                            value,
                                          ) {
                                            setDialogState(
                                              () {
                                                agreement =
                                                    value ??
                                                        agreement;
                                              },
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ),

                      _formFooter(
                        primaryLabel: editing
                            ? 'Update Franchise'
                            : 'Save Franchise',
                        onCancel: () {
                          Navigator.pop(
                            dialogContext,
                          );
                        },
                        onSave: () {
                          if (owner.text
                                  .trim()
                                  .isEmpty ||
                              phone.text
                                  .trim()
                                  .isEmpty ||
                              city.text
                                  .trim()
                                  .isEmpty) {
                            AppToast.error(
                              context,
                              'Owner name, phone and city are required.',
                              title:
                                  'Validation Error',
                            );
                            return;
                          }

                          final parsedDeposit =
                              int.tryParse(
                            deposit.text
                                .trim(),
                          );

                          if (deposit.text
                                  .trim()
                                  .isNotEmpty &&
                              parsedDeposit ==
                                  null) {
                            AppToast.error(
                              context,
                              'Enter a valid security deposit.',
                              title:
                                  'Invalid Deposit',
                            );
                            return;
                          }

                          final data =
                              {
                            'id': item?[
                                    'id'] ??
                                DateTime
                                    .now()
                                    .millisecondsSinceEpoch,
                            'owner':
                                owner.text
                                    .trim(),
                            'phone':
                                phone.text
                                    .trim(),
                            'email':
                                email.text
                                    .trim(),
                            'city':
                                city.text
                                    .trim(),
                            'territory':
                                territory
                                    .text
                                    .trim(),
                            'gst':
                                gst.text
                                    .trim(),
                            'pan':
                                pan.text
                                    .trim(),
                            'aadhaar':
                                aadhaar
                                    .text
                                    .trim(),
                            'securityDeposit':
                                parsedDeposit ??
                                    0,
                            'commission':
                                commission
                                    .text
                                    .trim(),
                            'status':
                                status,
                            'renewalDate':
                                renewal
                                    .text
                                    .trim(),
                            'agreement':
                                agreement,
                          };

                          setState(() {
                            if (!editing) {
                              franchises
                                  .insert(
                                0,
                                data,
                              );
                            } else {
                              final index =
                                  franchises
                                      .indexWhere(
                                (e) =>
                                    e['id'] ==
                                    item['id'],
                              );

                              if (index !=
                                  -1) {
                                franchises[
                                        index] =
                                    data;
                              }
                            }
                          });

                          saved = true;

                          Navigator.pop(
                            dialogContext,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    if (saved && mounted) {
      AppToast.success(
        context,
        editing
            ? '${owner.text.trim()} updated successfully.'
            : '${owner.text.trim()} added successfully.',
        title: editing
            ? 'Franchise Updated'
            : 'Franchise Added',
      );
    }

    owner.dispose();
    phone.dispose();
    email.dispose();
    city.dispose();
    territory.dispose();
    gst.dispose();
    pan.dispose();
    aadhaar.dispose();
    deposit.dispose();
    commission.dispose();
    renewal.dispose();
  }

  Widget _formHeader({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onClose,
  }) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 18,
      ),
      decoration:
          const BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.vertical(
          top:
              Radius.circular(18),
        ),
        border: Border(
          bottom: BorderSide(
            color:
                Color(
              0xFFE5E7EB,
            ),
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFEEF2FF,
              ),
              borderRadius:
                  BorderRadius.circular(
                12,
              ),
            ),
            child: Icon(
              icon,
              color:
                  const Color(
                0xFF4F46E5,
              ),
            ),
          ),
          const SizedBox(
            width: 14,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
              children: [
                Text(
                  title,
                  style:
                      const TextStyle(
                    fontSize: 21,
                    fontWeight:
                        FontWeight
                            .w800,
                  ),
                ),
                Text(
                  subtitle,
                  style:
                      const TextStyle(
                    fontSize: 12,
                    color:
                        Color(
                      0xFF64748B,
                    ),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onClose,
            icon:
                const Icon(
              Icons.close_rounded,
            ),
          ),
        ],
      ),
    );
  }

  Widget _formSection({
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(
          14,
        ),
        border: Border.all(
          color:
              const Color(
            0xFFE5E7EB,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration:
                    BoxDecoration(
                  color:
                      const Color(
                    0xFFEEF2FF,
                  ),
                  borderRadius:
                      BorderRadius
                          .circular(
                    10,
                  ),
                ),
                child: Icon(
                  icon,
                  size: 18,
                  color:
                      const Color(
                    0xFF4F46E5,
                  ),
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment
                          .start,
                  children: [
                    Text(
                      title,
                      style:
                          const TextStyle(
                        fontSize: 15,
                        fontWeight:
                            FontWeight
                                .w700,
                      ),
                    ),
                    Text(
                      subtitle,
                      style:
                          const TextStyle(
                        fontSize: 11,
                        color:
                            Color(
                          0xFF64748B,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 18,
          ),
          child,
        ],
      ),
    );
  }

  Widget _formGrid(
    bool twoColumns,
    List<Widget> fields,
  ) {
    if (!twoColumns) {
      return Column(
        children:
            List.generate(
          fields.length,
          (index) => Padding(
            padding:
                EdgeInsets.only(
              bottom:
                  index ==
                          fields.length -
                              1
                      ? 0
                      : 14,
            ),
            child:
                fields[index],
          ),
        ),
      );
    }

    return Wrap(
      spacing: 16,
      runSpacing: 14,
      children: fields
          .map(
            (field) =>
                SizedBox(
              width: 405,
              child: field,
            ),
          )
          .toList(),
    );
  }

  Widget _formField(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool requiredField = false,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType:
          keyboardType,
      decoration:
          InputDecoration(
        labelText:
            requiredField
                ? '$label *'
                : label,
        prefixIcon: Icon(
          icon,
          size: 18,
        ),
        filled: true,
        fillColor:
            const Color(
          0xFFF8FAFC,
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFFE2E8F0,
            ),
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFF4F46E5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _formDropdown({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?>
        onChanged,
  }) {
    return DropdownButtonFormField<
        String>(
      value: value,
      isExpanded: true,
      decoration:
          InputDecoration(
        labelText: label,
        filled: true,
        fillColor:
            const Color(
          0xFFF8FAFC,
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFFE2E8F0,
            ),
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFF4F46E5,
            ),
          ),
        ),
      ),
      items: items
          .map(
            (e) =>
                DropdownMenuItem(
              value: e,
              child: Text(e),
            ),
          )
          .toList(),
      onChanged: onChanged,
    );
  }

  Widget _formFooter({
    required String primaryLabel,
    required VoidCallback onCancel,
    required VoidCallback onSave,
  }) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 15,
      ),
      decoration:
          const BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.vertical(
          bottom:
              Radius.circular(18),
        ),
        border: Border(
          top: BorderSide(
            color:
                Color(
              0xFFE5E7EB,
            ),
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment:
            MainAxisAlignment.end,
        children: [
          SizedBox(
            width: 95,
            height: 44,
            child: TextButton(
              onPressed: onCancel,
              child:
                  const Text(
                'Cancel',
              ),
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          SizedBox(
            width: 175,
            height: 44,
            child:
                ElevatedButton.icon(
              style:
                  ElevatedButton
                      .styleFrom(
                minimumSize:
                    const Size(
                  0,
                  44,
                ),
                maximumSize:
                    const Size(
                  175,
                  44,
                ),
              ),
              onPressed: onSave,
              icon:
                  const Icon(
                Icons.save_outlined,
                size: 18,
              ),
              label: Text(
                primaryLabel,
                maxLines: 1,
                softWrap: false,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _view(
    Map<String, dynamic> item,
  ) {
    showDialog(
      context: context,
      builder: (
        dialogContext,
      ) {
        return AlertDialog(
          title:
              Text(item['owner']),
          content: SizedBox(
            width: 500,
            child: Column(
              mainAxisSize:
                  MainAxisSize.min,
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                _detailRow(
                  'Phone',
                  item['phone'],
                ),
                _detailRow(
                  'Email',
                  item['email'],
                ),
                _detailRow(
                  'City',
                  item['city'],
                ),
                _detailRow(
                  'Territory',
                  item['territory'],
                ),
                _detailRow(
                  'GST',
                  item['gst'],
                ),
                _detailRow(
                  'PAN',
                  item['pan'],
                ),
                _detailRow(
                  'Aadhaar',
                  item['aadhaar'],
                ),
                _detailRow(
                  'Security Deposit',
                  '₹${item['securityDeposit']}',
                ),
                _detailRow(
                  'Commission',
                  item['commission'],
                ),
                _detailRow(
                  'Agreement',
                  item['agreement'],
                ),
                _detailRow(
                  'Status',
                  item['status'],
                ),
                if (item['approvalStatus'] != null)
  _detailRow(
    'Approval Status',
    item['approvalStatus'],
  ),

if (item['approvalDate'] != null)
  _detailRow(
    'Approval Date',
    item['approvalDate'],
  ),

if ((item['rejectionReason'] ?? '')
    .toString()
    .isNotEmpty)
  _detailRow(
    'Rejection Reason',
    item['rejectionReason'],
  ),
                _detailRow(
                  'Renewal',
                  item['renewalDate'],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                );
              },
              child:
                  const Text(
                'Close',
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _detailRow(
    String label,
    dynamic value,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        bottom: 8,
      ),
      child: Row(
        children: [
          SizedBox(
            width: 145,
            child: Text(
              '$label:',
              style:
                  const TextStyle(
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value?.toString() ??
                  '-',
            ),
          ),
        ],
      ),
    );
  }
Future<void> _approveFranchise(
  Map<String, dynamic> item,
) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        title: const Row(
          children: [
            Icon(
              Icons.check_circle_outline,
              color: Color(0xFF16A34A),
            ),
            SizedBox(width: 10),
            Text('Approve Franchise'),
          ],
        ),
        content: Text(
          'Are you sure you want to approve ${item['owner']} as an active franchise partner?',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(
                dialogContext,
                false,
              );
            },
            child: const Text('Cancel'),
          ),
          SizedBox(
            width: 110,
            height: 42,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(0, 42),
                maximumSize: const Size(110, 42),
                backgroundColor:
                    const Color(0xFF16A34A),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              icon: const Icon(
                Icons.check,
                size: 17,
              ),
              label: const Text('Approve'),
            ),
          ),
        ],
      );
    },
  );

  if (confirmed != true) {
    return;
  }

  setState(() {
    item['status'] = 'Active';
    item['approvalStatus'] = 'Approved';
    item['approvalDate'] = _todayDate();
    item['rejectionReason'] = '';
  });

  if (!mounted) return;

  AppToast.success(
    context,
    '${item['owner']} has been approved successfully.',
    title: 'Franchise Approved',
  );
}
String _todayDate() {
  final now = DateTime.now();

  final day =
      now.day.toString().padLeft(2, '0');

  final month =
      now.month.toString().padLeft(2, '0');

  return '$day/$month/${now.year}';
}
Future<void> _rejectFranchise(
  Map<String, dynamic> item,
) async {
  final reasonController =
      TextEditingController();

  bool rejected = false;

  await showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return AlertDialog(
        title: const Row(
          children: [
            Icon(
              Icons.cancel_outlined,
              color: Color(0xFFDC2626),
            ),
            SizedBox(width: 10),
            Text('Reject Franchise'),
          ],
        ),
        content: SizedBox(
          width: 450,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                'Reject ${item['owner']} franchise application?',
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 16),

              TextField(
                controller: reasonController,
                minLines: 3,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Rejection Reason *',
                  hintText:
                      'Enter reason for rejection...',
                  alignLabelWithHint: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
            },
            child: const Text('Cancel'),
          ),
          SizedBox(
            width: 110,
            height: 42,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize:
                    const Size(0, 42),
                maximumSize:
                    const Size(110, 42),
                backgroundColor:
                    const Color(0xFFDC2626),
                foregroundColor:
                    Colors.white,
              ),
              onPressed: () {
                final reason =
                    reasonController.text.trim();

                if (reason.isEmpty) {
                  AppToast.error(
                    context,
                    'Please enter rejection reason.',
                    title:
                        'Rejection Reason Required',
                  );
                  return;
                }

                setState(() {
                  item['status'] = 'Rejected';
                  item['approvalStatus'] =
                      'Rejected';
                  item['rejectionReason'] =
                      reason;
                  item['approvalDate'] =
                      _todayDate();
                });

                rejected = true;

                Navigator.pop(
                  dialogContext,
                );
              },
              icon: const Icon(
                Icons.close,
                size: 17,
              ),
              label: const Text('Reject'),
            ),
          ),
        ],
      );
    },
  );

  final name = item['owner'].toString();

  reasonController.dispose();

  if (!rejected || !mounted) {
    return;
  }

  AppToast.success(
    context,
    '$name franchise application has been rejected.',
    title: 'Franchise Rejected',
  );
}
  Future<void> _delete(
    Map<String, dynamic> item,
  ) async {
    final yes =
        await showDialog<bool>(
      context: context,
      builder: (
        dialogContext,
      ) {
        return AlertDialog(
          title:
              const Text(
            'Delete Franchise',
          ),
          content: Text(
            'Delete ${item['owner']}?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child:
                  const Text(
                'Cancel',
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child:
                  const Text(
                'Delete',
                style: TextStyle(
                  color:
                      Colors.red,
                ),
              ),
            ),
          ],
        );
      },
    );

    if (yes != true) return;

    final name =
        item['owner'].toString();

    setState(() {
      franchises.removeWhere(
        (e) =>
            e['id'] == item['id'],
      );
    });

    if (!mounted) return;

    AppToast.success(
      context,
      '$name deleted successfully.',
      title: 'Franchise Deleted',
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String title;
  final String value;

  const _MiniStat({
    required this.title,
    required this.value,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      height: 90,
      padding:
          const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color:
              const Color(
            0xFFE5E7EB,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Text(
            title,
            style:
                const TextStyle(
              color:
                  Color(
                0xFF64748B,
              ),
              fontSize: 11,
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
            value,
            style:
                const TextStyle(
              fontSize: 21,
              fontWeight:
                  FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

const _headerStyle =
    TextStyle(
  fontSize: 8.5,
  fontWeight: FontWeight.w700,
  color: Color(0xFF64748B),
);