import 'package:flutter/material.dart';
import '../../../core/widgets/app_toast.dart';

class AdminInventoryScreen extends StatefulWidget {
  const AdminInventoryScreen({super.key});

  @override
  State<AdminInventoryScreen> createState() =>
      _AdminInventoryScreenState();
}

class _AdminInventoryScreenState
    extends State<AdminInventoryScreen> {
  final List<Map<String, dynamic>> inventory = [
    {
      'id': 1,
      'name': 'PET Bottle 1 Litre',
      'type': 'Raw Material',
      'sku': 'RM-PET-1L',
      'unit': 'Pcs',
      'stock': 1850,
      'minStock': 500,
      'purchaseRate': 6.5,
      'batch': 'PET-090326',
      'supplier': 'Shree Packaging',
    },
    {
      'id': 2,
      'name': 'Bottle Caps',
      'type': 'Raw Material',
      'sku': 'RM-CAP-01',
      'unit': 'Pcs',
      'stock': 420,
      'minStock': 600,
      'purchaseRate': 0.65,
      'batch': 'CAP-082626',
      'supplier': 'Balaji Plastics',
    },
    {
      'id': 3,
      'name': '500 ml Water Bottle',
      'type': 'Finished Product',
      'sku': 'FP-500ML',
      'unit': 'Bottles',
      'stock': 850,
      'minStock': 200,
      'purchaseRate': 8.0,
      'batch': 'WB-500-0903',
      'supplier': 'Own Production',
    },
    {
      'id': 4,
      'name': '20 Litre Jar',
      'type': 'Finished Product',
      'sku': 'FP-20L',
      'unit': 'Jars',
      'stock': 86,
      'minStock': 100,
      'purchaseRate': 115.0,
      'batch': 'JAR-090326',
      'supplier': 'Own Production',
    },
    {
      'id': 5,
      'name': 'Shrink Film',
      'type': 'Raw Material',
      'sku': 'RM-SF-01',
      'unit': 'Kg',
      'stock': 240,
      'minStock': 80,
      'purchaseRate': 145.0,
      'batch': 'SF-0901',
      'supplier': 'Packwell Industries',
    },
  ];
final List<Map<String, dynamic>> stockRequests = [
  {
    'id': 1,
    'itemId': 2,
    'itemName': 'Bottle Caps',
    'type': 'Stock In',
    'quantity': 500,
    'requestedBy': 'Inventory Manager',
    'date': '10 Sep 2026',
    'status': 'Pending',
    'reason': 'New supplier stock received',
  },
];
int get pendingApprovals {
  return stockRequests
      .where((e) => e['status'] == 'Pending')
      .length;
}
  String search = '';
  String typeFilter = 'All';

  List<Map<String, dynamic>> get filtered {
    final key = search.trim().toLowerCase();

    return inventory.where((item) {
      final matchesSearch =
          key.isEmpty ||
          item['name']
              .toString()
              .toLowerCase()
              .contains(key) ||
          item['sku']
              .toString()
              .toLowerCase()
              .contains(key) ||
          item['supplier']
              .toString()
              .toLowerCase()
              .contains(key);

      final matchesType =
          typeFilter == 'All' ||
          item['type'] == typeFilter;

      return matchesSearch && matchesType;
    }).toList();
  }

  int get lowStock {
    return inventory
        .where(
          (item) =>
              (item['stock'] as num) <=
              (item['minStock'] as num),
        )
        .length;
  }

  double get totalValue {
    return inventory.fold<double>(
      0,
      (sum, item) =>
          sum +
          ((item['stock'] as num).toDouble() *
              (item['purchaseRate'] as num)
                  .toDouble()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (
        context,
        constraints,
      ) {
        final desktop =
            constraints.maxWidth >= 900;

        return Container(
          width: double.infinity,
          height: double.infinity,
          color: const Color(0xFFF5F7FB),
          child: SingleChildScrollView(
            padding: EdgeInsets.all(
              desktop ? 28 : 16,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints:
                    const BoxConstraints(
                  maxWidth: 1350,
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    _header(desktop),
                    const SizedBox(height: 22),
                    _stats(desktop),
                    const SizedBox(height: 20),
                    _toolbar(desktop),
                    const SizedBox(height: 14),
                    desktop
                        ? _table()
                        : _mobileList(),
                        const SizedBox(height: 22),

_stockApprovalSection(desktop),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _header(bool desktop) {
    return Row(
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                'Inventory',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Manage raw materials and finished products',
                style: TextStyle(
                  color:
                      Color(0xFF64748B),
                ),
              ),
            ],
          ),
        ),
        if (desktop)
          Row(
            children: [
              SizedBox(
                width: 145,
                height: 44,
                child:
                    OutlinedButton.icon(
                  style:
                      OutlinedButton
                          .styleFrom(
                    minimumSize:
                        const Size(
                      145,
                      44,
                    ),
                    maximumSize:
                        const Size(
                      145,
                      44,
                    ),
                  ),
                  onPressed:
                      _stockEntry,
                  icon: const Icon(
                    Icons
                        .move_to_inbox_outlined,
                    size: 18,
                  ),
                  label: const Text(
                    'Stock Entry',
                    maxLines: 1,
                    softWrap: false,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                width: 135,
                height: 44,
                child:
                    ElevatedButton.icon(
                  style:
                      ElevatedButton
                          .styleFrom(
                    minimumSize:
                        const Size(
                      135,
                      44,
                    ),
                    maximumSize:
                        const Size(
                      135,
                      44,
                    ),
                  ),
                  onPressed: () {
                    _openItemForm();
                  },
                  icon: const Icon(
                    Icons.add,
                    size: 18,
                  ),
                  label:
                      const Text(
                    'Add Item',
                    maxLines: 1,
                    softWrap: false,
                  ),
                ),
              ),
            ],
          ),
      ],
    );
  }

  Widget _stats(bool desktop) {
    final data = [
  [
    'Total Items',
    '${inventory.length}',
    Icons.inventory_2_outlined,
  ],
  [
    'Low Stock',
    '$lowStock',
    Icons.warning_amber,
  ],
  [
    'Pending Approval',
    '$pendingApprovals',
    Icons.approval_outlined,
  ],
  [
    'Stock Value',
    '₹${totalValue.toStringAsFixed(0)}',
    Icons.currency_rupee,
  ],
];

    if (desktop) {
      return Row(
        children: List.generate(
          data.length,
          (index) => Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                right:
                    index ==
                            data.length - 1
                        ? 0
                        : 14,
              ),
              child: _InventoryStat(
                title:
                    data[index][0]
                        .toString(),
                value:
                    data[index][1]
                        .toString(),
                icon:
                    data[index][2]
                        as IconData,
              ),
            ),
          ),
        ),
      );
    }

    return Column(
      children: data
          .map(
            (item) => Padding(
              padding:
                  const EdgeInsets.only(
                bottom: 10,
              ),
              child: _InventoryStat(
                title:
                    item[0].toString(),
                value:
                    item[1].toString(),
                icon:
                    item[2] as IconData,
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _toolbar(bool desktop) {
    return Container(
      padding:
          const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color:
              const Color(0xFFE5E7EB),
        ),
      ),
      child: desktop
          ? Row(
              children: [
                Expanded(
                  child: _searchBox(),
                ),
                const SizedBox(
                  width: 14,
                ),
                SizedBox(
                  width: 190,
                  child: _typeDropdown(),
                ),
              ],
            )
          : Column(
              children: [
                _searchBox(),
                const SizedBox(
                  height: 10,
                ),
                _typeDropdown(),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      child:
                          OutlinedButton(
                        onPressed:
                            _stockEntry,
                        child:
                            const Text(
                          'Stock Entry',
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child:
                          ElevatedButton(
                        onPressed: () {
                          _openItemForm();
                        },
                        child:
                            const Text(
                          'Add Item',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
    );
  }

  Widget _searchBox() {
    return TextField(
      onChanged: (value) {
        setState(() {
          search = value;
        });
      },
      decoration:
          const InputDecoration(
        hintText:
            'Search item, SKU or supplier...',
        prefixIcon:
            Icon(Icons.search),
      ),
    );
  }

  Widget _typeDropdown() {
    return DropdownButtonFormField<
        String>(
      value: typeFilter,
      items: const [
        DropdownMenuItem(
          value: 'All',
          child:
              Text('All Types'),
        ),
        DropdownMenuItem(
          value:
              'Raw Material',
          child:
              Text('Raw Material'),
        ),
        DropdownMenuItem(
          value:
              'Finished Product',
          child: Text(
            'Finished Product',
          ),
        ),
      ],
      onChanged: (value) {
        setState(() {
          typeFilter =
              value ?? 'All';
        });
      },
    );
  }

  Widget _table() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(14),
        border: Border.all(
          color:
              const Color(0xFFE5E7EB),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding:
                const EdgeInsets.all(
              14,
            ),
            color:
                const Color(0xFFF8FAFC),
            child: const Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'ITEM',
                    style:
                        _inventoryHeader,
                  ),
                ),
                Expanded(
                  child: Text(
                    'TYPE',
                    style:
                        _inventoryHeader,
                  ),
                ),
                Expanded(
                  child: Text(
                    'STOCK',
                    style:
                        _inventoryHeader,
                  ),
                ),
                Expanded(
                  child: Text(
                    'MIN STOCK',
                    style:
                        _inventoryHeader,
                  ),
                ),
                Expanded(
                  child: Text(
                    'RATE',
                    style:
                        _inventoryHeader,
                  ),
                ),
                Expanded(
                  child: Text(
                    'BATCH',
                    style:
                        _inventoryHeader,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'SUPPLIER',
                    style:
                        _inventoryHeader,
                  ),
                ),
                SizedBox(
                  width: 90,
                  child: Text(
                    'ACTIONS',
                    style:
                        _inventoryHeader,
                  ),
                ),
              ],
            ),
          ),
          if (filtered.isEmpty)
            const Padding(
              padding:
                  EdgeInsets.symmetric(
                vertical: 50,
              ),
              child: Text(
                'No inventory item found.',
              ),
            )
          else
            ...filtered.map(
              _tableRow,
            ),
        ],
      ),
    );
  }

  Widget _tableRow(
    Map<String, dynamic> item,
  ) {
    final low =
        (item['stock'] as num) <=
        (item['minStock'] as num);

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 13,
      ),
      decoration:
          const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color:
                Color(0xFFF1F5F9),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  item['name']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 11,
                    fontWeight:
                        FontWeight.w700,
                  ),
                ),
                Text(
                  item['sku']
                      .toString(),
                  style:
                      const TextStyle(
                    fontSize: 9,
                    color:
                        Color(
                      0xFF94A3B8,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Text(
              item['type']
                  .toString(),
              style:
                  const TextStyle(
                fontSize: 10,
              ),
            ),
          ),
          Expanded(
            child: Text(
              '${item['stock']} ${item['unit']}',
              style: TextStyle(
                fontSize: 10,
                color: low
                    ? Colors.red
                    : Colors.black87,
                fontWeight: low
                    ? FontWeight.w700
                    : FontWeight.w400,
              ),
            ),
          ),
          Expanded(
            child: Text(
              '${item['minStock']}',
            ),
          ),
          Expanded(
            child: Text(
              '₹${item['purchaseRate']}',
            ),
          ),
          Expanded(
            child: Text(
              item['batch']
                  .toString(),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              item['supplier']
                  .toString(),
            ),
          ),
          SizedBox(
            width: 90,
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Edit',
                  onPressed: () {
                    _openItemForm(
                      item: item,
                    );
                  },
                  icon:
                      const Icon(
                    Icons.edit_outlined,
                    size: 17,
                  ),
                ),
                IconButton(
                  tooltip: 'Delete',
                  onPressed: () {
                    _deleteItem(
                      item,
                    );
                  },
                  icon:
                      const Icon(
                    Icons.delete_outline,
                    color:
                        Colors.red,
                    size: 17,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _mobileList() {
    if (filtered.isEmpty) {
      return Container(
        width: double.infinity,
        padding:
            const EdgeInsets.all(35),
        alignment: Alignment.center,
        child: const Text(
          'No inventory item found.',
        ),
      );
    }

    return Column(
      children:
          filtered.map((item) {
        final low =
            (item['stock'] as num) <=
            (item['minStock'] as num);

        return Container(
          width: double.infinity,
          margin:
              const EdgeInsets.only(
            bottom: 12,
          ),
          padding:
              const EdgeInsets.all(
            15,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius:
                BorderRadius.circular(
              14,
            ),
            border: Border.all(
              color:
                  const Color(
                0xFFE5E7EB,
              ),
            ),
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                item['name']
                    .toString(),
                style:
                    const TextStyle(
                  fontWeight:
                      FontWeight.w700,
                ),
              ),
              const SizedBox(
                height: 4,
              ),
              Text(
                '${item['sku']} • ${item['type']}',
              ),
              const SizedBox(
                height: 8,
              ),
              Text(
                'Stock: ${item['stock']} ${item['unit']}',
                style: TextStyle(
                  color: low
                      ? Colors.red
                      : Colors.black87,
                  fontWeight: low
                      ? FontWeight.w700
                      : FontWeight.w400,
                ),
              ),
              Text(
                'Supplier: ${item['supplier']}',
              ),
              Row(
                mainAxisAlignment:
                    MainAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: () {
                      _openItemForm(
                        item: item,
                      );
                    },
                    icon:
                        const Icon(
                      Icons.edit_outlined,
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      _deleteItem(
                        item,
                      );
                    },
                    icon:
                        const Icon(
                      Icons.delete_outline,
                      color:
                          Colors.red,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  // =========================================================
  // STOCK ENTRY PROFESSIONAL DIALOG
  // =========================================================

  Future<void> _stockEntry() async {
    if (inventory.isEmpty) return;

    int selectedId =
        inventory.first['id'] as int;

    String action =
        'Stock In';

    final qtyController =
        TextEditingController();

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (
        dialogContext,
      ) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            return Dialog(
              backgroundColor:
                  Colors.transparent,
              child:
                  ConstrainedBox(
                constraints:
                    const BoxConstraints(
                  maxWidth: 520,
                ),
                child: Container(
                  decoration:
                      BoxDecoration(
                    color:
                        const Color(
                      0xFFF8FAFC,
                    ),
                    borderRadius:
                        BorderRadius
                            .circular(
                      18,
                    ),
                    boxShadow:
                        const [
                      BoxShadow(
                        color:
                            Color(
                          0x22000000,
                        ),
                        blurRadius:
                            25,
                        offset:
                            Offset(
                          0,
                          10,
                        ),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize:
                        MainAxisSize.min,
                    children: [
                      Container(
                        padding:
                            const EdgeInsets
                                .all(
                          20,
                        ),
                        decoration:
                            const BoxDecoration(
                          color:
                              Colors.white,
                          borderRadius:
                              BorderRadius
                                  .vertical(
                            top:
                                Radius
                                    .circular(
                              18,
                            ),
                          ),
                          border:
                              Border(
                            bottom:
                                BorderSide(
                              color:
                                  Color(
                                0xFFE5E7EB,
                              ),
                            ),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 42,
                              height: 42,
                              decoration:
                                  BoxDecoration(
                                color:
                                    const Color(
                                  0xFFEEF2FF,
                                ),
                                borderRadius:
                                    BorderRadius
                                        .circular(
                                  12,
                                ),
                              ),
                              child:
                                  const Icon(
                                Icons
                                    .sync_alt_rounded,
                                color:
                                    Color(
                                  0xFF4F46E5,
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 12,
                            ),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment
                                        .start,
                                children: [
                                  Text(
                                    'Stock Entry',
                                    style:
                                        TextStyle(
                                      fontSize: 19,
                                      fontWeight:
                                          FontWeight
                                              .w800,
                                    ),
                                  ),
                                  Text(
                                    'Add or remove inventory quantity',
                                    style:
                                        TextStyle(
                                      color:
                                          Color(
                                        0xFF64748B,
                                      ),
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                Navigator.pop(
                                  dialogContext,
                                );
                              },
                              icon:
                                  const Icon(
                                Icons
                                    .close_rounded,
                              ),
                            ),
                          ],
                        ),
                      ),

                      Padding(
                        padding:
                            const EdgeInsets
                                .all(
                          22,
                        ),
                        child: Column(
                          children: [
                            DropdownButtonFormField<
                                int>(
                              value:
                                  selectedId,
                              isExpanded:
                                  true,
                              decoration:
                                  _dialogInputDecoration(
                                'Inventory Item',
                                Icons
                                    .inventory_2_outlined,
                              ),
                              items:
                                  inventory
                                      .map(
                                (item) {
                                  return DropdownMenuItem<
                                      int>(
                                    value:
                                        item['id']
                                            as int,
                                    child:
                                        Text(
                                      item['name']
                                          .toString(),
                                    ),
                                  );
                                },
                              ).toList(),
                              onChanged:
                                  (
                                value,
                              ) {
                                if (value ==
                                    null) {
                                  return;
                                }

                                setDialogState(
                                  () {
                                    selectedId =
                                        value;
                                  },
                                );
                              },
                            ),

                            const SizedBox(
                              height: 14,
                            ),

                            DropdownButtonFormField<
                                String>(
                              value:
                                  action,
                              decoration:
                                  _dialogInputDecoration(
                                'Transaction Type',
                                Icons
                                    .swap_vert_rounded,
                              ),
                              items:
                                  const [
                                DropdownMenuItem(
                                  value:
                                      'Stock In',
                                  child:
                                      Text(
                                    'Stock In',
                                  ),
                                ),
                                DropdownMenuItem(
                                  value:
                                      'Stock Out',
                                  child:
                                      Text(
                                    'Stock Out',
                                  ),
                                ),
                              ],
                              onChanged:
                                  (
                                value,
                              ) {
                                if (value ==
                                    null) {
                                  return;
                                }

                                setDialogState(
                                  () {
                                    action =
                                        value;
                                  },
                                );
                              },
                            ),

                            const SizedBox(
                              height: 14,
                            ),

                            TextField(
                              controller:
                                  qtyController,
                              keyboardType:
                                  TextInputType
                                      .number,
                              decoration:
                                  _dialogInputDecoration(
                                'Quantity',
                                Icons
                                    .numbers_rounded,
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        padding:
                            const EdgeInsets
                                .all(
                          18,
                        ),
                        decoration:
                            const BoxDecoration(
                          color:
                              Colors.white,
                          borderRadius:
                              BorderRadius
                                  .vertical(
                            bottom:
                                Radius
                                    .circular(
                              18,
                            ),
                          ),
                          border:
                              Border(
                            top:
                                BorderSide(
                              color:
                                  Color(
                                0xFFE5E7EB,
                              ),
                            ),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment:
                              MainAxisAlignment
                                  .end,
                          children: [
                            SizedBox(
                              width: 90,
                              height: 44,
                              child:
                                  TextButton(
                                onPressed: () {
                                  Navigator.pop(
                                    dialogContext,
                                  );
                                },
                                child:
                                    const Text(
                                  'Cancel',
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 145,
                              height: 44,
                              child:
                                  ElevatedButton
                                      .icon(
                                style:
                                    ElevatedButton
                                        .styleFrom(
                                  minimumSize:
                                      const Size(
                                    145,
                                    44,
                                  ),
                                  maximumSize:
                                      const Size(
                                    145,
                                    44,
                                  ),
                                ),
                                onPressed: () {
                                  final qty =
                                      int.tryParse(
                                            qtyController
                                                .text
                                                .trim(),
                                          ) ??
                                          0;

                                  if (qty <= 0) {
                                    AppToast.error(
                                      context,
                                      'Please enter a valid quantity.',
                                      title:
                                          'Invalid Quantity',
                                    );
                                    return;
                                  }

                                  final index =
                                      inventory.indexWhere(
                                    (item) =>
                                        item['id'] ==
                                        selectedId,
                                  );

                                  if (index ==
                                      -1) {
                                    return;
                                  }

                                  final current =
                                      (inventory[index]
                                                  ['stock']
                                              as num)
                                          .toInt();

                                  if (action ==
                                          'Stock Out' &&
                                      qty >
                                          current) {
                                    AppToast.error(
                                      context,
                                      'Stock out quantity is greater than available stock.',
                                      title:
                                          'Insufficient Stock',
                                    );
                                    return;
                                  }

                                  final itemName =
    inventory[index]['name'].toString();

setState(() {
  stockRequests.insert(
    0,
    {
      'id': DateTime.now()
          .millisecondsSinceEpoch,
      'itemId': selectedId,
      'itemName': itemName,
      'type': action,
      'quantity': qty,
      'requestedBy':
          'Inventory Manager',
      'date': _currentDate(),
      'status': 'Pending',
      'reason': action == 'Stock In'
          ? 'Stock received / purchase entry'
          : 'Stock issue / adjustment',
    },
  );
});

Navigator.pop(
  dialogContext,
);

AppToast.success(
  context,
  '$itemName - $action request submitted for approval.',
  title: 'Approval Requested',
);                                },
                                icon:
                                    const Icon(
                                  Icons
                                      .save_outlined,
                                  size: 18,
                                ),
                                label:
                                    const Text(
                                  'Save Entry',
                                  maxLines: 1,
                                  softWrap:
                                      false,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    qtyController.dispose();
  }
Widget _stockApprovalSection(bool desktop) {
  final pending = stockRequests
      .where((e) => e['status'] == 'Pending')
      .toList();

  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(
        color: const Color(0xFFE5E7EB),
      ),
    ),
    child: Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color:
                      const Color(0xFFFFF7ED),
                  borderRadius:
                      BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.approval_outlined,
                  color:
                      Color(0xFFEA580C),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Inventory Approval',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight:
                            FontWeight.w800,
                      ),
                    ),
                    Text(
                      '$pendingApprovals pending stock transactions',
                      style: const TextStyle(
                        fontSize: 11,
                        color:
                            Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const Divider(height: 1),

        if (pending.isEmpty)
          const Padding(
            padding: EdgeInsets.all(35),
            child: Center(
              child: Text(
                'No pending inventory approvals.',
                style: TextStyle(
                  color:
                      Color(0xFF64748B),
                ),
              ),
            ),
          )
        else if (desktop)
          _approvalDesktopTable(pending)
        else
          _approvalMobileList(pending),
      ],
    ),
  );
}
Widget _approvalDesktopTable(
  List<Map<String, dynamic>> data,
) {
  return Column(
    children: [
      Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
        color: const Color(0xFFF8FAFC),
        child: const Row(
          children: [
            Expanded(
              flex: 2,
              child: Text(
                'ITEM',
                style: _inventoryHeader,
              ),
            ),
            Expanded(
              child: Text(
                'TYPE',
                style: _inventoryHeader,
              ),
            ),
            Expanded(
              child: Text(
                'QTY',
                style: _inventoryHeader,
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                'REQUESTED BY',
                style: _inventoryHeader,
              ),
            ),
            Expanded(
              child: Text(
                'DATE',
                style: _inventoryHeader,
              ),
            ),
            SizedBox(
              width: 150,
              child: Text(
                'ACTION',
                style: _inventoryHeader,
              ),
            ),
          ],
        ),
      ),

      ...data.map(
        (request) =>
            _approvalDesktopRow(request),
      ),
    ],
  );
}
Widget _approvalDesktopRow(
  Map<String, dynamic> request,
) {
  final type =
      request['type'].toString();

  return Container(
    padding: const EdgeInsets.symmetric(
      horizontal: 16,
      vertical: 13,
    ),
    decoration: const BoxDecoration(
      border: Border(
        bottom: BorderSide(
          color: Color(0xFFF1F5F9),
        ),
      ),
    ),
    child: Row(
      children: [
        Expanded(
          flex: 2,
          child: Text(
            request['itemName'].toString(),
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),

        Expanded(
          child: Text(
            type,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: type == 'Stock In'
                  ? const Color(0xFF16A34A)
                  : const Color(0xFFEA580C),
            ),
          ),
        ),

        Expanded(
          child: Text(
            request['quantity'].toString(),
            style: const TextStyle(
              fontSize: 10,
            ),
          ),
        ),

        Expanded(
          flex: 2,
          child: Text(
            request['requestedBy']
                .toString(),
            style: const TextStyle(
              fontSize: 10,
            ),
          ),
        ),

        Expanded(
          child: Text(
            request['date'].toString(),
            style: const TextStyle(
              fontSize: 9,
            ),
          ),
        ),

        SizedBox(
          width: 150,
          child: Row(
            children: [
              IconButton(
                tooltip: 'Approve',
                onPressed: () {
                  _approveStockRequest(
                    request,
                  );
                },
                icon: const Icon(
                  Icons
                      .check_circle_outline,
                  color:
                      Color(0xFF16A34A),
                  size: 19,
                ),
              ),
              IconButton(
                tooltip: 'Reject',
                onPressed: () {
                  _rejectStockRequest(
                    request,
                  );
                },
                icon: const Icon(
                  Icons.cancel_outlined,
                  color:
                      Color(0xFFDC2626),
                  size: 19,
                ),
              ),
              IconButton(
                tooltip: 'View',
                onPressed: () {
                  _viewStockRequest(
                    request,
                  );
                },
                icon: const Icon(
                  Icons.visibility_outlined,
                  size: 18,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}
Widget _approvalMobileList(
  List<Map<String, dynamic>> data,
) {
  return Padding(
    padding: const EdgeInsets.all(14),
    child: Column(
      children: data.map(
        (request) {
          return Container(
            width: double.infinity,
            margin:
                const EdgeInsets.only(
              bottom: 10,
            ),
            padding:
                const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color:
                  const Color(0xFFF8FAFC),
              borderRadius:
                  BorderRadius.circular(10),
              border: Border.all(
                color:
                    const Color(0xFFE2E8F0),
              ),
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        request['itemName']
                            .toString(),
                        style:
                            const TextStyle(
                          fontWeight:
                              FontWeight.w700,
                        ),
                      ),
                    ),
                    _approvalBadge(
                      request['status']
                          .toString(),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _approvalInfo(
                  'Type',
                  request['type'],
                ),
                _approvalInfo(
                  'Quantity',
                  request['quantity'],
                ),
                _approvalInfo(
                  'Requested By',
                  request['requestedBy'],
                ),
                _approvalInfo(
                  'Date',
                  request['date'],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () {
                        _viewStockRequest(
                          request,
                        );
                      },
                      icon: const Icon(
                        Icons
                            .visibility_outlined,
                        size: 16,
                      ),
                      label:
                          const Text('View'),
                    ),
                    ElevatedButton.icon(
                      style:
                          ElevatedButton.styleFrom(
                        minimumSize:
                            const Size(0, 40),
                        backgroundColor:
                            const Color(
                          0xFF16A34A,
                        ),
                        foregroundColor:
                            Colors.white,
                      ),
                      onPressed: () {
                        _approveStockRequest(
                          request,
                        );
                      },
                      icon: const Icon(
                        Icons.check,
                        size: 16,
                      ),
                      label: const Text(
                        'Approve',
                      ),
                    ),
                    OutlinedButton.icon(
                      style:
                          OutlinedButton.styleFrom(
                        foregroundColor:
                            const Color(
                          0xFFDC2626,
                        ),
                      ),
                      onPressed: () {
                        _rejectStockRequest(
                          request,
                        );
                      },
                      icon: const Icon(
                        Icons.close,
                        size: 16,
                      ),
                      label:
                          const Text('Reject'),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ).toList(),
    ),
  );
}
Future<void> _approveStockRequest(
  Map<String, dynamic> request,
) async {
  final confirm =
      await showDialog<bool>(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        title:
            const Text('Approve Stock Entry'),
        content: Text(
          'Approve ${request['type']} of ${request['quantity']} for ${request['itemName']}?',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(
                dialogContext,
                false,
              );
            },
            child: const Text('Cancel'),
          ),
          SizedBox(
            width: 110,
            height: 42,
            child: ElevatedButton(
              style:
                  ElevatedButton.styleFrom(
                minimumSize:
                    const Size(0, 42),
                maximumSize:
                    const Size(110, 42),
                backgroundColor:
                    const Color(
                  0xFF16A34A,
                ),
                foregroundColor:
                    Colors.white,
              ),
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child:
                  const Text('Approve'),
            ),
          ),
        ],
      );
    },
  );

  if (confirm != true) return;

  final itemIndex =
      inventory.indexWhere(
    (item) =>
        item['id'] ==
        request['itemId'],
  );

  if (itemIndex == -1) {
    AppToast.error(
      context,
      'Inventory item not found.',
      title: 'Unable to Approve',
    );
    return;
  }

  final current =
      (inventory[itemIndex]['stock']
              as num)
          .toInt();

  final qty =
      (request['quantity'] as num)
          .toInt();

  if (request['type'] ==
          'Stock Out' &&
      qty > current) {
    AppToast.error(
      context,
      'Available stock is insufficient for this request.',
      title: 'Insufficient Stock',
    );
    return;
  }

  setState(() {
    inventory[itemIndex]['stock'] =
        request['type'] == 'Stock In'
            ? current + qty
            : current - qty;

    request['status'] = 'Approved';
    request['approvedDate'] =
        _currentDate();
  });

  if (!mounted) return;

  AppToast.success(
    context,
    '${request['itemName']} stock request approved successfully.',
    title: 'Inventory Approved',
  );
}
Future<void> _rejectStockRequest(
  Map<String, dynamic> request,
) async {
  final reasonController =
      TextEditingController();

  bool rejected = false;

  await showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return AlertDialog(
        title: const Text(
          'Reject Stock Entry',
        ),
        content: SizedBox(
          width: 420,
          child: TextField(
            controller:
                reasonController,
            minLines: 3,
            maxLines: 5,
            decoration:
                const InputDecoration(
              labelText:
                  'Rejection Reason *',
              hintText:
                  'Enter reason...',
              alignLabelWithHint:
                  true,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(
                dialogContext,
              );
            },
            child: const Text('Cancel'),
          ),
          SizedBox(
            width: 105,
            height: 42,
            child: ElevatedButton(
              style:
                  ElevatedButton.styleFrom(
                minimumSize:
                    const Size(0, 42),
                maximumSize:
                    const Size(105, 42),
                backgroundColor:
                    const Color(
                  0xFFDC2626,
                ),
                foregroundColor:
                    Colors.white,
              ),
              onPressed: () {
                final reason =
                    reasonController.text
                        .trim();

                if (reason.isEmpty) {
                  AppToast.error(
                    context,
                    'Please enter rejection reason.',
                    title:
                        'Reason Required',
                  );
                  return;
                }

                setState(() {
                  request['status'] =
                      'Rejected';
                  request[
                          'rejectionReason'] =
                      reason;
                  request['approvedDate'] =
                      _currentDate();
                });

                rejected = true;

                Navigator.pop(
                  dialogContext,
                );
              },
              child:
                  const Text('Reject'),
            ),
          ),
        ],
      );
    },
  );

  reasonController.dispose();

  if (!rejected || !mounted) {
    return;
  }

  AppToast.success(
    context,
    '${request['itemName']} stock request rejected.',
    title: 'Request Rejected',
  );
}
void _viewStockRequest(
  Map<String, dynamic> request,
) {
  showDialog(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        title: const Text(
          'Stock Request Details',
        ),
        content: SizedBox(
          width: 450,
          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              _approvalInfo(
                'Item',
                request['itemName'],
              ),
              _approvalInfo(
                'Transaction',
                request['type'],
              ),
              _approvalInfo(
                'Quantity',
                request['quantity'],
              ),
              _approvalInfo(
                'Requested By',
                request['requestedBy'],
              ),
              _approvalInfo(
                'Date',
                request['date'],
              ),
              _approvalInfo(
                'Reason',
                request['reason'] ?? '-',
              ),
              _approvalInfo(
                'Status',
                request['status'],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(
                dialogContext,
              );
            },
            child: const Text('Close'),
          ),
        ],
      );
    },
  );
}
Widget _approvalInfo(
  String label,
  dynamic value,
) {
  return Padding(
    padding:
        const EdgeInsets.only(
      bottom: 8,
    ),
    child: Row(
      children: [
        SizedBox(
          width: 110,
          child: Text(
            label,
            style: const TextStyle(
              color:
                  Color(0xFF64748B),
            ),
          ),
        ),
        Expanded(
          child: Text(
            value?.toString() ?? '-',
            style: const TextStyle(
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _approvalBadge(
  String status,
) {
  return Container(
    padding:
        const EdgeInsets.symmetric(
      horizontal: 9,
      vertical: 5,
    ),
    decoration: BoxDecoration(
      color:
          const Color(0xFFFFF7ED),
      borderRadius:
          BorderRadius.circular(15),
    ),
    child: Text(
      status,
      style: const TextStyle(
        color: Color(0xFFEA580C),
        fontSize: 9,
        fontWeight: FontWeight.w700,
      ),
    ),
  );
}

String _currentDate() {
  final now = DateTime.now();

  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  return '${now.day.toString().padLeft(2, '0')} '
      '${months[now.month - 1]} '
      '${now.year}';
}
  // =========================================================
  // ADD / EDIT PROFESSIONAL DIALOG
  // =========================================================

  Future<void> _openItemForm({
    Map<String, dynamic>? item,
  }) async {
    final editing =
        item != null;

    final name =
        TextEditingController(
      text: item?['name'] ?? '',
    );

    final sku =
        TextEditingController(
      text: item?['sku'] ?? '',
    );

    final stock =
        TextEditingController(
      text:
          item?['stock']
                  ?.toString() ??
              '',
    );

    final minStock =
        TextEditingController(
      text:
          item?['minStock']
                  ?.toString() ??
              '',
    );

    final rate =
        TextEditingController(
      text:
          item?['purchaseRate']
                  ?.toString() ??
              '',
    );

    final batch =
        TextEditingController(
      text:
          item?['batch'] ?? '',
    );

    final supplier =
        TextEditingController(
      text:
          item?['supplier'] ?? '',
    );

    String type =
        item?['type'] ??
            'Raw Material';

    String unit =
        item?['unit'] ??
            'Pcs';

    bool saved = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (
        dialogContext,
      ) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            final desktop =
                MediaQuery.of(
                      context,
                    ).size.width >=
                    900;

            return Dialog(
              backgroundColor:
                  Colors.transparent,
              insetPadding:
                  EdgeInsets.symmetric(
                horizontal:
                    desktop ? 80 : 14,
                vertical:
                    desktop ? 30 : 16,
              ),
              child:
                  ConstrainedBox(
                constraints:
                    BoxConstraints(
                  maxWidth:
                      desktop
                          ? 860
                          : 600,
                  maxHeight:
                      MediaQuery.of(
                            context,
                          ).size.height *
                          .9,
                ),
                child: Container(
                  decoration:
                      BoxDecoration(
                    color:
                        const Color(
                      0xFFF8FAFC,
                    ),
                    borderRadius:
                        BorderRadius
                            .circular(
                      18,
                    ),
                    boxShadow:
                        const [
                      BoxShadow(
                        color:
                            Color(
                          0x22000000,
                        ),
                        blurRadius:
                            28,
                        offset:
                            Offset(
                          0,
                          12,
                        ),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      _inventoryDialogHeader(
                        editing
                            ? 'Edit Inventory Item'
                            : 'Add Inventory Item',
                        'Manage item, stock, price and supplier information',
                        () {
                          Navigator.pop(
                            dialogContext,
                          );
                        },
                      ),

                      Expanded(
                        child:
                            SingleChildScrollView(
                          padding:
                              EdgeInsets.all(
                            desktop
                                ? 22
                                : 16,
                          ),
                          child:
                              LayoutBuilder(
                            builder: (
                              context,
                              constraints,
                            ) {
                              final twoColumns =
                                  constraints
                                          .maxWidth >=
                                      650;

                              return Column(
                                children: [
                                  _inventorySection(
                                    title:
                                        'Item Information',
                                    subtitle:
                                        'Identification and classification',
                                    icon:
                                        Icons
                                            .category_outlined,
                                    child:
                                        _inventoryGrid(
                                      twoColumns,
                                      [
                                        _inventoryField(
                                          name,
                                          'Item Name',
                                          Icons
                                              .inventory_2_outlined,
                                          requiredField:
                                              true,
                                        ),
                                        _inventoryField(
                                          sku,
                                          'SKU',
                                          Icons
                                              .qr_code_2_outlined,
                                        ),
                                        _inventoryDropdown(
                                          label:
                                              'Type',
                                          value:
                                              type,
                                          items:
                                              const [
                                            'Raw Material',
                                            'Finished Product',
                                          ],
                                          onChanged:
                                              (
                                            value,
                                          ) {
                                            setDialogState(
                                              () {
                                                type =
                                                    value ??
                                                        type;
                                              },
                                            );
                                          },
                                        ),
                                        _inventoryDropdown(
                                          label:
                                              'Unit',
                                          value:
                                              unit,
                                          items:
                                              const [
                                            'Pcs',
                                            'Bottles',
                                            'Jars',
                                            'Kg',
                                          ],
                                          onChanged:
                                              (
                                            value,
                                          ) {
                                            setDialogState(
                                              () {
                                                unit =
                                                    value ??
                                                        unit;
                                              },
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 18,
                                  ),

                                  _inventorySection(
                                    title:
                                        'Stock & Pricing',
                                    subtitle:
                                        'Quantity and purchase information',
                                    icon:
                                        Icons
                                            .stacked_bar_chart_outlined,
                                    child:
                                        _inventoryGrid(
                                      twoColumns,
                                      [
                                        _inventoryField(
                                          stock,
                                          'Current Stock',
                                          Icons
                                              .inventory_outlined,
                                          keyboardType:
                                              TextInputType
                                                  .number,
                                        ),
                                        _inventoryField(
                                          minStock,
                                          'Minimum Stock',
                                          Icons
                                              .warning_amber_outlined,
                                          keyboardType:
                                              TextInputType
                                                  .number,
                                        ),
                                        _inventoryField(
                                          rate,
                                          'Purchase Rate',
                                          Icons
                                              .currency_rupee,
                                          keyboardType:
                                              const TextInputType
                                                  .numberWithOptions(
                                            decimal:
                                                true,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 18,
                                  ),

                                  _inventorySection(
                                    title:
                                        'Batch & Supplier',
                                    subtitle:
                                        'Traceability and vendor details',
                                    icon:
                                        Icons
                                            .local_shipping_outlined,
                                    child:
                                        _inventoryGrid(
                                      twoColumns,
                                      [
                                        _inventoryField(
                                          batch,
                                          'Batch Number',
                                          Icons
                                              .tag_outlined,
                                        ),
                                        _inventoryField(
                                          supplier,
                                          'Supplier',
                                          Icons
                                              .business_outlined,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ),

                      Container(
                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal: 24,
                          vertical: 15,
                        ),
                        decoration:
                            const BoxDecoration(
                          color:
                              Colors.white,
                          borderRadius:
                              BorderRadius
                                  .vertical(
                            bottom:
                                Radius
                                    .circular(
                              18,
                            ),
                          ),
                          border:
                              Border(
                            top:
                                BorderSide(
                              color:
                                  Color(
                                0xFFE5E7EB,
                              ),
                            ),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment:
                              MainAxisAlignment
                                  .end,
                          children: [
                            SizedBox(
                              width: 95,
                              height: 44,
                              child:
                                  TextButton(
                                onPressed: () {
                                  Navigator.pop(
                                    dialogContext,
                                  );
                                },
                                child:
                                    const Text(
                                  'Cancel',
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 145,
                              height: 44,
                              child:
                                  ElevatedButton
                                      .icon(
                                style:
                                    ElevatedButton
                                        .styleFrom(
                                  minimumSize:
                                      const Size(
                                    145,
                                    44,
                                  ),
                                  maximumSize:
                                      const Size(
                                    145,
                                    44,
                                  ),
                                ),
                                onPressed: () {
                                  if (name.text
                                      .trim()
                                      .isEmpty) {
                                    AppToast.error(
                                      context,
                                      'Item name is required.',
                                      title:
                                          'Validation Error',
                                    );
                                    return;
                                  }

                                  final stockValue =
                                      int.tryParse(
                                            stock.text
                                                .trim(),
                                          ) ??
                                          0;

                                  final minimumValue =
                                      int.tryParse(
                                            minStock.text
                                                .trim(),
                                          ) ??
                                          0;

                                  final rateValue =
                                      double.tryParse(
                                            rate.text
                                                .trim(),
                                          ) ??
                                          0;

                                  if (stockValue <
                                          0 ||
                                      minimumValue <
                                          0 ||
                                      rateValue <
                                          0) {
                                    AppToast.error(
                                      context,
                                      'Stock, minimum stock and rate cannot be negative.',
                                      title:
                                          'Invalid Value',
                                    );
                                    return;
                                  }

                                  final data =
                                      {
                                    'id': item?[
                                            'id'] ??
                                        DateTime.now()
                                            .millisecondsSinceEpoch,
                                    'name':
                                        name.text
                                            .trim(),
                                    'type':
                                        type,
                                    'sku':
                                        sku.text
                                            .trim(),
                                    'unit':
                                        unit,
                                    'stock':
                                        stockValue,
                                    'minStock':
                                        minimumValue,
                                    'purchaseRate':
                                        rateValue,
                                    'batch':
                                        batch.text
                                            .trim(),
                                    'supplier':
                                        supplier.text
                                            .trim(),
                                  };

                                  setState(() {
                                    if (!editing) {
                                      inventory.insert(
                                        0,
                                        data,
                                      );
                                    } else {
                                      final index =
                                          inventory.indexWhere(
                                        (e) =>
                                            e['id'] ==
                                            item['id'],
                                      );

                                      if (index !=
                                          -1) {
                                        inventory[index] =
                                            data;
                                      }
                                    }
                                  });

                                  saved = true;

                                  Navigator.pop(
                                    dialogContext,
                                  );
                                },
                                icon:
                                    const Icon(
                                  Icons
                                      .save_outlined,
                                  size: 18,
                                ),
                                label: Text(
                                  editing
                                      ? 'Update Item'
                                      : 'Save Item',
                                  maxLines: 1,
                                  softWrap:
                                      false,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    if (saved && mounted) {
      AppToast.success(
        context,
        editing
            ? '${name.text.trim()} updated successfully.'
            : '${name.text.trim()} added successfully.',
        title: editing
            ? 'Inventory Updated'
            : 'Inventory Item Added',
      );
    }

    name.dispose();
    sku.dispose();
    stock.dispose();
    minStock.dispose();
    rate.dispose();
    batch.dispose();
    supplier.dispose();
  }

  // =========================================================
  // PROFESSIONAL FORM HELPERS
  // =========================================================

  Widget _inventoryDialogHeader(
    String title,
    String subtitle,
    VoidCallback onClose,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 18,
      ),
      decoration:
          const BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.vertical(
          top:
              Radius.circular(18),
        ),
        border: Border(
          bottom: BorderSide(
            color:
                Color(
              0xFFE5E7EB,
            ),
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFEEF2FF,
              ),
              borderRadius:
                  BorderRadius.circular(
                12,
              ),
            ),
            child: const Icon(
              Icons
                  .inventory_2_outlined,
              color:
                  Color(
                0xFF4F46E5,
              ),
            ),
          ),
          const SizedBox(
            width: 14,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style:
                      const TextStyle(
                    fontSize: 21,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
                Text(
                  subtitle,
                  style:
                      const TextStyle(
                    fontSize: 12,
                    color:
                        Color(
                      0xFF64748B,
                    ),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onClose,
            icon:
                const Icon(
              Icons.close_rounded,
            ),
          ),
        ],
      ),
    );
  }

  Widget _inventorySection({
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(
        18,
      ),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(
          14,
        ),
        border: Border.all(
          color:
              const Color(
            0xFFE5E7EB,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration:
                    BoxDecoration(
                  color:
                      const Color(
                    0xFFEEF2FF,
                  ),
                  borderRadius:
                      BorderRadius
                          .circular(
                    10,
                  ),
                ),
                child: Icon(
                  icon,
                  size: 18,
                  color:
                      const Color(
                    0xFF4F46E5,
                  ),
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment
                          .start,
                  children: [
                    Text(
                      title,
                      style:
                          const TextStyle(
                        fontSize: 15,
                        fontWeight:
                            FontWeight
                                .w700,
                      ),
                    ),
                    Text(
                      subtitle,
                      style:
                          const TextStyle(
                        fontSize: 11,
                        color:
                            Color(
                          0xFF64748B,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 18,
          ),
          child,
        ],
      ),
    );
  }

  Widget _inventoryGrid(
    bool twoColumns,
    List<Widget> fields,
  ) {
    if (!twoColumns) {
      return Column(
        children:
            List.generate(
          fields.length,
          (index) => Padding(
            padding:
                EdgeInsets.only(
              bottom:
                  index ==
                          fields.length -
                              1
                      ? 0
                      : 14,
            ),
            child:
                fields[index],
          ),
        ),
      );
    }

    return Wrap(
      spacing: 16,
      runSpacing: 14,
      children: fields
          .map(
            (field) =>
                SizedBox(
              width: 370,
              child: field,
            ),
          )
          .toList(),
    );
  }

  Widget _inventoryField(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool requiredField = false,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType:
          keyboardType,
      decoration:
          InputDecoration(
        labelText:
            requiredField
                ? '$label *'
                : label,
        prefixIcon: Icon(
          icon,
          size: 18,
        ),
        filled: true,
        fillColor:
            const Color(
          0xFFF8FAFC,
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFFE2E8F0,
            ),
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFF4F46E5,
            ),
            width: 1.2,
          ),
        ),
      ),
    );
  }

  Widget _inventoryDropdown({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?>
        onChanged,
  }) {
    return DropdownButtonFormField<
        String>(
      value: value,
      isExpanded: true,
      decoration:
          InputDecoration(
        labelText: label,
        filled: true,
        fillColor:
            const Color(
          0xFFF8FAFC,
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFFE2E8F0,
            ),
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
            10,
          ),
          borderSide:
              const BorderSide(
            color:
                Color(
              0xFF4F46E5,
            ),
          ),
        ),
      ),
      items: items
          .map(
            (e) =>
                DropdownMenuItem(
              value: e,
              child: Text(e),
            ),
          )
          .toList(),
      onChanged: onChanged,
    );
  }

  InputDecoration _dialogInputDecoration(
    String label,
    IconData icon,
  ) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(
        icon,
        size: 18,
      ),
      filled: true,
      fillColor: Colors.white,
      enabledBorder:
          OutlineInputBorder(
        borderRadius:
            BorderRadius.circular(
          10,
        ),
        borderSide:
            const BorderSide(
          color:
              Color(
            0xFFE2E8F0,
          ),
        ),
      ),
      focusedBorder:
          OutlineInputBorder(
        borderRadius:
            BorderRadius.circular(
          10,
        ),
        borderSide:
            const BorderSide(
          color:
              Color(
            0xFF4F46E5,
          ),
        ),
      ),
    );
  }

  Future<void> _deleteItem(
    Map<String, dynamic> item,
  ) async {
    final yes =
        await showDialog<bool>(
      context: context,
      builder: (
        dialogContext,
      ) {
        return AlertDialog(
          title:
              const Text(
            'Delete Item',
          ),
          content: Text(
            'Delete ${item['name']}?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child:
                  const Text(
                'Cancel',
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child:
                  const Text(
                'Delete',
                style: TextStyle(
                  color:
                      Colors.red,
                ),
              ),
            ),
          ],
        );
      },
    );

    if (yes != true) return;

    final itemName =
        item['name'].toString();

    setState(() {
      inventory.removeWhere(
        (e) =>
            e['id'] == item['id'],
      );
    });

    if (!mounted) return;

    AppToast.success(
      context,
      '$itemName deleted successfully.',
      title:
          'Inventory Item Deleted',
    );
  }
}

class _InventoryStat
    extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _InventoryStat({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      height: 95,
      padding:
          const EdgeInsets.all(
        16,
      ),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(
          14,
        ),
        border: Border.all(
          color:
              const Color(
            0xFFE5E7EB,
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFEEF2FF,
              ),
              borderRadius:
                  BorderRadius.circular(
                10,
              ),
            ),
            child: Icon(
              icon,
              color:
                  const Color(
                0xFF4F46E5,
              ),
            ),
          ),
          const SizedBox(
            width: 12,
          ),
          Expanded(
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style:
                      const TextStyle(
                    color:
                        Color(
                      0xFF64748B,
                    ),
                    fontSize: 11,
                  ),
                ),
                Text(
                  value,
                  style:
                      const TextStyle(
                    fontSize: 20,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const _inventoryHeader =
    TextStyle(
  fontSize: 8.5,
  fontWeight: FontWeight.w700,
  color: Color(0xFF64748B),
);