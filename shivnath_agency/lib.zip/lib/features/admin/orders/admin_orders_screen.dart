import 'package:flutter/material.dart';
import '../../../core/widgets/app_toast.dart';
class AdminOrdersScreen extends StatefulWidget {
  const AdminOrdersScreen({super.key});

  @override
  State<AdminOrdersScreen> createState() => _AdminOrdersScreenState();
}

class _AdminOrdersScreenState extends State<AdminOrdersScreen> {
  final List<Map<String, dynamic>> orders = [
    {
      'id': 'ORD-1001',
      'franchise': 'Rahul Sharma',
      'city': 'Raipur',
      'date': '07 Sep 2026',
      'items': 6,
      'amount': 48500,
      'status': 'Plant Approval',
      'payment': 'Pending',
    },
    {
      'id': 'ORD-1002',
      'franchise': 'Aqua Point',
      'city': 'Bhilai',
      'date': '06 Sep 2026',
      'items': 4,
      'amount': 32200,
      'status': 'Invoice Generated',
      'payment': 'Partial',
    },
    {
      'id': 'ORD-1003',
      'franchise': 'Shiv Water',
      'city': 'Bilaspur',
      'date': '05 Sep 2026',
      'items': 8,
      'amount': 68400,
      'status': 'Dispatch',
      'payment': 'Paid',
    },
    {
      'id': 'ORD-1004',
      'franchise': 'Pure Aqua Agency',
      'city': 'Durg',
      'date': '04 Sep 2026',
      'items': 3,
      'amount': 24800,
      'status': 'Delivered',
      'payment': 'Paid',
    },
  ];

  String search = '';
  String filter = 'All';

  List<Map<String, dynamic>> get filtered {
    final q = search.toLowerCase();

    return orders.where((order) {
      final matches =
          q.isEmpty ||
          order['id'].toString().toLowerCase().contains(q) ||
          order['franchise'].toString().toLowerCase().contains(q) ||
          order['city'].toString().toLowerCase().contains(q);

      final status = filter == 'All' || order['status'] == filter;

      return matches && status;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, constraints) {
        final desktop = constraints.maxWidth >= 900;

        return Container(
          color: const Color(0xFFF5F7FB),
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            padding: EdgeInsets.all(desktop ? 28 : 16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1350),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Orders',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Manage franchise orders, approval and dispatch',
                      style: TextStyle(color: Color(0xFF64748B)),
                    ),
                    const SizedBox(height: 22),
                    _stats(desktop),
                    const SizedBox(height: 20),
                    _toolbar(desktop),
                    const SizedBox(height: 14),
                    desktop ? _desktop() : _mobile(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _stats(bool desktop) {
    final data = [
      ['Total Orders', '${orders.length}', Icons.shopping_bag_outlined],
      ['Approval Pending', '1', Icons.schedule_outlined],
      ['In Dispatch', '1', Icons.local_shipping_outlined],
      ['Order Value', '₹1,73,900', Icons.currency_rupee],
    ];

    if (!desktop) {
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 4,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.45,
        ),
        itemBuilder: (_, i) => _OrderStat(
          title: data[i][0] as String,
          value: data[i][1] as String,
          icon: data[i][2] as IconData,
        ),
      );
    }

    return Row(
      children: List.generate(4, (i) {
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i == 3 ? 0 : 14),
            child: _OrderStat(
              title: data[i][0] as String,
              value: data[i][1] as String,
              icon: data[i][2] as IconData,
            ),
          ),
        );
      }),
    );
  }

  Widget _toolbar(bool desktop) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: _orderCard(),
      child: desktop
          ? Row(
              children: [
                Expanded(child: _search()),
                const SizedBox(width: 14),
                SizedBox(width: 220, child: _filter()),
              ],
            )
          : Column(
              children: [
                _search(),
                const SizedBox(height: 10),
                _filter(),
              ],
            ),
    );
  }

  Widget _search() {
    return TextField(
      onChanged: (v) => setState(() => search = v),
      decoration: const InputDecoration(
        hintText: 'Search order, franchise or city...',
        prefixIcon: Icon(Icons.search),
      ),
    );
  }

  Widget _filter() {
    return DropdownButtonFormField<String>(
      value: filter,
      decoration: const InputDecoration(labelText: 'Order Status'),
      items: const [
        'All',
        'Order Placement',
        'Plant Approval',
        'Invoice Generated',
        'Dispatch',
        'Delivered',
        'Payment Collection',
      ]
          .map(
            (e) => DropdownMenuItem(
              value: e,
              child: Text(e),
            ),
          )
          .toList(),
      onChanged: (value) {
        if (value != null) setState(() => filter = value);
      },
    );
  }

  Widget _desktop() {
    return Container(
      decoration: _orderCard(),
      child: Column(
        children: [
          _tableRow(null, true),
          ...filtered.map((order) => _tableRow(order, false)),
        ],
      ),
    );
  }

  Widget _tableRow(Map<String, dynamic>? order, bool header) {
    final cells = header
        ? ['ORDER', 'FRANCHISE', 'DATE', 'ITEMS', 'AMOUNT', 'STATUS', 'PAYMENT']
        : [
            order!['id'],
            '${order['franchise']}\n${order['city']}',
            order['date'],
            '${order['items']} Items',
            '₹${order['amount']}',
            order['status'],
            order['payment'],
          ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      decoration: BoxDecoration(
        color: header ? const Color(0xFFF8FAFC) : Colors.white,
        border: const Border(
          bottom: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: Row(
        children: List.generate(cells.length, (i) {
          if (!header && i == 5) {
            return Expanded(
              flex: 2,
              child: InkWell(
                onTap: () => _changeStatus(order!),
                child: _statusBadge(cells[i].toString()),
              ),
            );
          }

          return Expanded(
            flex: i == 1 || i == 5 ? 2 : 1,
            child: Text(
              cells[i].toString(),
              style: TextStyle(
                fontSize: header ? 9 : 11,
                fontWeight: header ? FontWeight.w700 : FontWeight.w500,
                color: header
                    ? const Color(0xFF64748B)
                    : const Color(0xFF1E293B),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _mobile() {
    return Column(
      children: filtered.map((order) {
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: _orderCard(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      order['id'],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  _statusBadge(order['status']),
                ],
              ),
              const SizedBox(height: 12),
              _info('Franchise', order['franchise']),
              _info('City', order['city']),
              _info('Date', order['date']),
              _info('Items', '${order['items']}'),
              _info('Amount', '₹${order['amount']}'),
              _info('Payment', order['payment']),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 42,
                child: OutlinedButton(
                  onPressed: () => _changeStatus(order),
                  child: const Text('Update Order Status'),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _statusBadge(String status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFEEF2FF),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: const TextStyle(
          color: Color(0xFF4F46E5),
          fontWeight: FontWeight.w700,
          fontSize: 9,
        ),
      ),
    );
  }

  Widget _info(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: const TextStyle(color: Color(0xFF64748B)),
            ),
          ),
          Expanded(
            child: Text(
              value.toString(),
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _changeStatus(Map<String, dynamic> order) async {
    final statuses = [
      'Order Placement',
      'Plant Approval',
      'Invoice Generated',
      'Dispatch',
      'Delivered',
      'Payment Collection',
    ];

    String selected = order['status'];

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (_, update) => AlertDialog(
            title: Text('Update ${order['id']}'),
            content: SizedBox(
              width: 400,
              child: DropdownButtonFormField<String>(
                value: selected,
                decoration: const InputDecoration(labelText: 'Order Status'),
                items: statuses
                    .map(
                      (status) => DropdownMenuItem(
                        value: status,
                        child: Text(status),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value != null) update(() => selected = value);
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Cancel'),
              ),
              SizedBox(
                width: 100,
                height: 44,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(0, 44),
                    maximumSize: const Size(100, 44),
                  ),
                  onPressed: () {
                    setState(() => order['status'] = selected);
                    Navigator.pop(dialogContext);

                    AppToast.success(
                      context,
                      '${order['id']} status changed to $selected.',
                      title: 'Order Status Updated',
                    );
                  },
                  child: const Text('Update'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _OrderStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _OrderStat({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 105,
      padding: const EdgeInsets.all(16),
      decoration: _orderCard(),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF4F46E5)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF64748B),
                    fontSize: 11,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

BoxDecoration _orderCard() => BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: const Color(0xFFE5E7EB)),
    );

