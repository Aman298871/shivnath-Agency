import 'package:flutter/material.dart';
import '../../../core/widgets/app_toast.dart';

class AdminProductsScreen extends StatefulWidget {
  const AdminProductsScreen({super.key});

  @override
  State<AdminProductsScreen> createState() => _AdminProductsScreenState();
}

class _AdminProductsScreenState extends State<AdminProductsScreen> {
  final List<Map<String, dynamic>> products = [
    {
      'id': 1,
      'name': '250ml Water Bottle',
      'sku': 'WATER-250',
      'size': '250 ml',
      'category': 'Bottle',
      'price': 5.0,
      'gst': 18,
      'stock': 1200,
      'status': 'Active',
    },
    {
      'id': 2,
      'name': '500ml Water Bottle',
      'sku': 'WATER-500',
      'size': '500 ml',
      'category': 'Bottle',
      'price': 10.0,
      'gst': 18,
      'stock': 850,
      'status': 'Active',
    },
    {
      'id': 3,
      'name': '1 Litre Water Bottle',
      'sku': 'WATER-1L',
      'size': '1 Litre',
      'category': 'Bottle',
      'price': 20.0,
      'gst': 18,
      'stock': 620,
      'status': 'Active',
    },
    {
      'id': 4,
      'name': '2 Litre Water Bottle',
      'sku': 'WATER-2L',
      'size': '2 Litre',
      'category': 'Bottle',
      'price': 35.0,
      'gst': 18,
      'stock': 310,
      'status': 'Active',
    },
    {
      'id': 5,
      'name': '5 Litre Water Jar',
      'sku': 'WATER-5L',
      'size': '5 Litre',
      'category': 'Jar',
      'price': 75.0,
      'gst': 18,
      'stock': 150,
      'status': 'Active',
    },
    {
      'id': 6,
      'name': '20 Litre Water Jar',
      'sku': 'WATER-20L',
      'size': '20 Litre',
      'category': 'Jar',
      'price': 120.0,
      'gst': 18,
      'stock': 86,
      'status': 'Active',
    },
  ];

  String search = '';
  String categoryFilter = 'All';

  List<Map<String, dynamic>> get filteredProducts {
    final keyword = search.trim().toLowerCase();

    return products.where((product) {
      final matchesSearch =
          keyword.isEmpty ||
          product['name'].toString().toLowerCase().contains(keyword) ||
          product['sku'].toString().toLowerCase().contains(keyword);

      final matchesCategory =
          categoryFilter == 'All' || product['category'] == categoryFilter;

      return matchesSearch && matchesCategory;
    }).toList();
  }

  int get activeProducts =>
      products.where((item) => item['status'] == 'Active').length;

  int get bottleCount =>
      products.where((item) => item['category'] == 'Bottle').length;

  int get jarCount =>
      products.where((item) => item['category'] == 'Jar').length;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop = constraints.maxWidth >= 900;

        return Container(
          width: double.infinity,
          height: double.infinity,
          color: const Color(0xFFF5F7FB),
          child: SingleChildScrollView(
            padding: EdgeInsets.all(desktop ? 28 : 16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1350),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(desktop),
                    const SizedBox(height: 22),
                    _buildStats(desktop),
                    const SizedBox(height: 20),
                    _buildToolbar(desktop),
                    const SizedBox(height: 14),
                    desktop ? _buildDesktopTable() : _buildMobileList(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(bool desktop) {
    return Row(
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Products',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF111827),
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Manage finished products and pricing',
                style: TextStyle(
                  fontSize: 13,
                  color: Color(0xFF64748B),
                ),
              ),
            ],
          ),
        ),
        if (desktop)
          SizedBox(
            width: 150,
            height: 44,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(150, 44),
                maximumSize: const Size(150, 44),
                backgroundColor: const Color(0xFF4F46E5),
                foregroundColor: Colors.white,
              ),
              onPressed: _openProductForm,
              icon: const Icon(Icons.add_rounded, size: 18),
              label: const Text(
                'Add Product',
                maxLines: 1,
                softWrap: false,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildStats(bool desktop) {
    final stats = [
      ['Total Products', '${products.length}', Icons.inventory_2_outlined],
      ['Active Products', '$activeProducts', Icons.check_circle_outline],
      ['Bottles', '$bottleCount', Icons.local_drink_outlined],
      ['Jars', '$jarCount', Icons.water_drop_outlined],
    ];

    if (desktop) {
      return Row(
        children: List.generate(stats.length, (index) {
          return Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                right: index == stats.length - 1 ? 0 : 14,
              ),
              child: _ProductStatCard(
                title: stats[index][0] as String,
                value: stats[index][1] as String,
                icon: stats[index][2] as IconData,
              ),
            ),
          );
        }),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: stats.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.45,
      ),
      itemBuilder: (_, index) {
        return _ProductStatCard(
          title: stats[index][0] as String,
          value: stats[index][1] as String,
          icon: stats[index][2] as IconData,
        );
      },
    );
  }

  Widget _buildToolbar(bool desktop) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: _cardDecoration(),
      child: desktop
          ? Row(
              children: [
                Expanded(child: _searchField()),
                const SizedBox(width: 14),
                SizedBox(width: 190, child: _categoryDropdown()),
              ],
            )
          : Column(
              children: [
                _searchField(),
                const SizedBox(height: 10),
                _categoryDropdown(),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: ElevatedButton.icon(
                    onPressed: _openProductForm,
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Add Product'),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _searchField() {
    return SizedBox(
      height: 44,
      child: TextField(
        onChanged: (value) => setState(() => search = value),
        decoration: InputDecoration(
          hintText: 'Search product or SKU...',
          prefixIcon: const Icon(Icons.search_rounded, size: 19),
          filled: true,
          fillColor: const Color(0xFFF8FAFC),
          contentPadding: EdgeInsets.zero,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color(0xFF4F46E5)),
          ),
        ),
      ),
    );
  }

  Widget _categoryDropdown() {
    return DropdownButtonFormField<String>(
      value: categoryFilter,
      isExpanded: true,
      decoration: const InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 12),
      ),
      items: const [
        DropdownMenuItem(value: 'All', child: Text('All Categories')),
        DropdownMenuItem(value: 'Bottle', child: Text('Bottle')),
        DropdownMenuItem(value: 'Jar', child: Text('Jar')),
      ],
      onChanged: (value) {
        if (value != null) {
          setState(() => categoryFilter = value);
        }
      },
    );
  }

  Widget _buildDesktopTable() {
    return Container(
      width: double.infinity,
      decoration: _cardDecoration(),
      child: Column(
        children: [
          _tableHeader(),
          if (filteredProducts.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 55),
              child: Text(
                'No products found.',
                style: TextStyle(
                  color: Color(0xFF64748B),
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          else
            ...filteredProducts.map(_tableRow),
        ],
      ),
    );
  }

  Widget _tableHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.vertical(top: Radius.circular(14)),
        border: Border(
          bottom: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: const Row(
        children: [
          Expanded(flex: 3, child: Text('PRODUCT', style: _headerStyle)),
          Expanded(child: Text('SIZE', style: _headerStyle)),
          Expanded(child: Text('CATEGORY', style: _headerStyle)),
          Expanded(child: Text('PRICE', style: _headerStyle)),
          Expanded(child: Text('GST', style: _headerStyle)),
          Expanded(child: Text('STOCK', style: _headerStyle)),
          Expanded(child: Text('STATUS', style: _headerStyle)),
          SizedBox(width: 100, child: Text('ACTIONS', style: _headerStyle)),
        ],
      ),
    );
  }

  Widget _tableRow(Map<String, dynamic> product) {
    final lowStock = (product['stock'] as num) <= 100;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFFF1F5F9)),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEEF2FF),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: const Icon(
                    Icons.inventory_2_outlined,
                    size: 18,
                    color: Color(0xFF4F46E5),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product['name'].toString(),
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        product['sku'].toString(),
                        style: const TextStyle(
                          fontSize: 9,
                          color: Color(0xFF94A3B8),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: _cell(product['size'])),
          Expanded(child: _cell(product['category'])),
          Expanded(child: _cell(_formatPrice(product['price']), bold: true)),
          Expanded(child: _cell('${product['gst']}%')),
          Expanded(
            child: Text(
              '${product['stock']}',
              style: TextStyle(
                fontSize: 10,
                color: lowStock ? Colors.red : const Color(0xFF111827),
                fontWeight: lowStock ? FontWeight.w700 : FontWeight.w400,
              ),
            ),
          ),
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: _statusBadge(product['status'].toString()),
            ),
          ),
          SizedBox(
            width: 100,
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Edit',
                  constraints: const BoxConstraints(minWidth: 35, minHeight: 35),
                  padding: EdgeInsets.zero,
                  onPressed: () => _openProductForm(product: product),
                  icon: const Icon(
                    Icons.edit_outlined,
                    size: 17,
                    color: Color(0xFF64748B),
                  ),
                ),
                IconButton(
                  tooltip: 'Delete',
                  constraints: const BoxConstraints(minWidth: 35, minHeight: 35),
                  padding: EdgeInsets.zero,
                  onPressed: () => _deleteProduct(product),
                  icon: const Icon(
                    Icons.delete_outline,
                    size: 17,
                    color: Colors.red,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _cell(dynamic value, {bool bold = false}) {
    return Text(
      value.toString(),
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontSize: 10,
        fontWeight: bold ? FontWeight.w600 : FontWeight.w400,
      ),
    );
  }

  Widget _buildMobileList() {
    if (filteredProducts.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(40),
        child: Center(child: Text('No products found.')),
      );
    }

    return Column(
      children: filteredProducts.map((product) {
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(15),
          decoration: _cardDecoration(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: const Color(0xFFEEF2FF),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.inventory_2_outlined,
                      color: Color(0xFF4F46E5),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          product['name'].toString(),
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          product['sku'].toString(),
                          style: const TextStyle(
                            fontSize: 11,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _statusBadge(product['status'].toString()),
                ],
              ),
              const SizedBox(height: 14),
              _mobileInfo('Size', product['size']),
              _mobileInfo('Category', product['category']),
              _mobileInfo('Price', _formatPrice(product['price'])),
              _mobileInfo('GST', '${product['gst']}%'),
              _mobileInfo('Stock', product['stock']),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: () => _openProductForm(product: product),
                    icon: const Icon(Icons.edit_outlined),
                  ),
                  IconButton(
                    onPressed: () => _deleteProduct(product),
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                  ),
                ],
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _mobileInfo(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                color: Color(0xFF64748B),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value.toString(),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openProductForm({
    Map<String, dynamic>? product,
  }) async {
    final editing = product != null;

    final nameController =
        TextEditingController(text: product?['name'] ?? '');
    final skuController =
        TextEditingController(text: product?['sku'] ?? '');
    final sizeController =
        TextEditingController(text: product?['size'] ?? '');
    final priceController =
        TextEditingController(text: product?['price']?.toString() ?? '');
    final gstController =
        TextEditingController(text: product?['gst']?.toString() ?? '18');
    final stockController =
        TextEditingController(text: product?['stock']?.toString() ?? '');

    String category = product?['category'] ?? 'Bottle';
    String status = product?['status'] ?? 'Active';
    bool saved = false;
    String savedName = '';

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, updateDialog) {
            final desktop = MediaQuery.of(context).size.width >= 800;

            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: EdgeInsets.symmetric(
                horizontal: desktop ? 70 : 14,
                vertical: desktop ? 30 : 16,
              ),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: 880,
                  maxHeight: MediaQuery.of(context).size.height * .9,
                ),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x22000000),
                        blurRadius: 28,
                        offset: Offset(0, 12),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      _dialogHeader(
                        editing ? 'Edit Product' : 'Add Product',
                        'Manage product information, pricing and inventory',
                        Icons.inventory_2_outlined,
                        () => Navigator.pop(dialogContext),
                      ),
                      Expanded(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.all(desktop ? 22 : 16),
                          child: Column(
                            children: [
                              _formSection(
                                title: 'Product Information',
                                subtitle: 'Basic product identification details',
                                icon: Icons.category_outlined,
                                child: _formGrid(
                                  desktop,
                                  [
                                    _professionalInput(
                                      controller: nameController,
                                      label: 'Product Name *',
                                      icon: Icons.inventory_2_outlined,
                                    ),
                                    _professionalInput(
                                      controller: skuController,
                                      label: 'SKU *',
                                      icon: Icons.qr_code_2_outlined,
                                    ),
                                    _professionalInput(
                                      controller: sizeController,
                                      label: 'Size *',
                                      hint: 'Example: 1 Litre',
                                      icon: Icons.straighten_outlined,
                                    ),
                                    _professionalDropdown(
                                      label: 'Category',
                                      value: category,
                                      icon: Icons.category_outlined,
                                      items: const ['Bottle', 'Jar'],
                                      onChanged: (value) {
                                        if (value != null) {
                                          updateDialog(() => category = value);
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 18),
                              _formSection(
                                title: 'Pricing & Tax',
                                subtitle: 'Configure selling price and GST',
                                icon: Icons.payments_outlined,
                                child: _formGrid(
                                  desktop,
                                  [
                                    _professionalInput(
                                      controller: priceController,
                                      label: 'Selling Price *',
                                      icon: Icons.currency_rupee,
                                      keyboardType:
                                          const TextInputType.numberWithOptions(
                                        decimal: true,
                                      ),
                                    ),
                                    _professionalInput(
                                      controller: gstController,
                                      label: 'GST %',
                                      icon: Icons.percent_rounded,
                                      keyboardType: TextInputType.number,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 18),
                              _formSection(
                                title: 'Inventory & Availability',
                                subtitle: 'Manage stock and product availability',
                                icon: Icons.warehouse_outlined,
                                child: _formGrid(
                                  desktop,
                                  [
                                    _professionalInput(
                                      controller: stockController,
                                      label: 'Current Stock',
                                      icon: Icons.inventory_outlined,
                                      keyboardType: TextInputType.number,
                                    ),
                                    _professionalDropdown(
                                      label: 'Status',
                                      value: status,
                                      icon: Icons.toggle_on_outlined,
                                      items: const ['Active', 'Inactive'],
                                      onChanged: (value) {
                                        if (value != null) {
                                          updateDialog(() => status = value);
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      _dialogFooter(
                        dialogContext: dialogContext,
                        saveLabel: editing ? 'Update Product' : 'Save Product',
                        onSave: () {
                          final name = nameController.text.trim();
                          final sku = skuController.text.trim();
                          final size = sizeController.text.trim();
                          final price =
                              double.tryParse(priceController.text.trim());
                          final gst =
                              int.tryParse(gstController.text.trim()) ?? 0;
                          final stock =
                              int.tryParse(stockController.text.trim()) ?? 0;

                          if (name.isEmpty) {
                            AppToast.error(
                              context,
                              'Product name is required.',
                              title: 'Validation Error',
                            );
                            return;
                          }

                          if (sku.isEmpty) {
                            AppToast.error(
                              context,
                              'SKU is required.',
                              title: 'Validation Error',
                            );
                            return;
                          }

                          if (size.isEmpty) {
                            AppToast.error(
                              context,
                              'Size is required.',
                              title: 'Validation Error',
                            );
                            return;
                          }

                          if (price == null || price < 0) {
                            AppToast.error(
                              context,
                              'Enter a valid selling price.',
                              title: 'Invalid Price',
                            );
                            return;
                          }

                          if (gst < 0 || gst > 100 || stock < 0) {
                            AppToast.error(
                              context,
                              'Enter valid GST and stock values.',
                              title: 'Invalid Details',
                            );
                            return;
                          }

                          final data = {
                            'id': editing
                                ? product['id']
                                : DateTime.now().millisecondsSinceEpoch,
                            'name': name,
                            'sku': sku,
                            'size': size,
                            'category': category,
                            'price': price,
                            'gst': gst,
                            'stock': stock,
                            'status': status,
                          };

                          setState(() {
                            if (editing) {
                              final index = products.indexWhere(
                                (item) => item['id'] == product['id'],
                              );
                              if (index != -1) products[index] = data;
                            } else {
                              products.insert(0, data);
                            }
                          });

                          saved = true;
                          savedName = name;
                          Navigator.pop(dialogContext);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    if (saved && mounted) {
      AppToast.success(
        context,
        editing
            ? '$savedName updated successfully.'
            : '$savedName added successfully.',
        title: editing ? 'Product Updated' : 'Product Added',
      );
    }

    nameController.dispose();
    skuController.dispose();
    sizeController.dispose();
    priceController.dispose();
    gstController.dispose();
    stockController.dispose();
  }

  Future<void> _deleteProduct(Map<String, dynamic> product) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete Product'),
          content: Text(
            'Are you sure you want to delete ${product['name']}?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text(
                'Delete',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );

    if (result != true) return;

    final name = product['name'].toString();

    setState(() {
      products.removeWhere((item) => item['id'] == product['id']);
    });

    if (!mounted) return;

    AppToast.success(
      context,
      '$name deleted successfully.',
      title: 'Product Deleted',
    );
  }

  Widget _dialogHeader(
    String title,
    String subtitle,
    IconData icon,
    VoidCallback close,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
        border: Border(
          bottom: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFEEF2FF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: const Color(0xFF4F46E5)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: close,
            icon: const Icon(Icons.close_rounded),
          ),
        ],
      ),
    );
  }

  Widget _formSection({
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: _cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: const Color(0xFFEEF2FF),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  icon,
                  size: 18,
                  color: const Color(0xFF4F46E5),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          child,
        ],
      ),
    );
  }

  Widget _formGrid(bool desktop, List<Widget> fields) {
    if (!desktop) {
      return Column(
        children: List.generate(
          fields.length,
          (i) => Padding(
            padding: EdgeInsets.only(
              bottom: i == fields.length - 1 ? 0 : 14,
            ),
            child: fields[i],
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (_, constraints) {
        final width = (constraints.maxWidth - 16) / 2;

        return Wrap(
          spacing: 16,
          runSpacing: 14,
          children: fields.map((field) {
            return SizedBox(width: width, child: field);
          }).toList(),
        );
      },
    );
  }

  Widget _professionalInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: _formDecoration(label, icon, hint: hint),
    );
  }

  Widget _professionalDropdown({
    required String label,
    required String value,
    required IconData icon,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      decoration: _formDecoration(label, icon),
      items: items
          .map(
            (item) => DropdownMenuItem(
              value: item,
              child: Text(item),
            ),
          )
          .toList(),
      onChanged: onChanged,
    );
  }

  InputDecoration _formDecoration(
    String label,
    IconData icon, {
    String? hint,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Icon(icon, size: 18),
      filled: true,
      fillColor: const Color(0xFFF8FAFC),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(
          color: Color(0xFF4F46E5),
          width: 1.2,
        ),
      ),
    );
  }

  Widget _dialogFooter({
    required BuildContext dialogContext,
    required String saveLabel,
    required VoidCallback onSave,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 15),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
        border: Border(
          top: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(
            width: 95,
            height: 44,
            child: TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 155,
            height: 44,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(155, 44),
                maximumSize: const Size(155, 44),
              ),
              onPressed: onSave,
              icon: const Icon(Icons.save_outlined, size: 17),
              label: Text(
                saveLabel,
                maxLines: 1,
                softWrap: false,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusBadge(String status) {
    final active = status == 'Active';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: active
            ? const Color(0xFFECFDF5)
            : const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 9,
          color: active
              ? const Color(0xFF15803D)
              : const Color(0xFF64748B),
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  String _formatPrice(dynamic value) {
    final number = value is num
        ? value.toDouble()
        : double.tryParse(value.toString()) ?? 0;

    if (number == number.roundToDouble()) {
      return '₹${number.toInt()}';
    }

    return '₹${number.toStringAsFixed(2)}';
  }

  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: const Color(0xFFE5E7EB)),
    );
  }
}

class _ProductStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _ProductStatCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 105,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFEEF2FF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: const Color(0xFF4F46E5)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF64748B),
                    fontSize: 11,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const TextStyle _headerStyle = TextStyle(
  fontSize: 8.5,
  fontWeight: FontWeight.w700,
  color: Color(0xFF64748B),
  letterSpacing: 0.3,
);