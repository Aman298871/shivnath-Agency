import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';
import '../../core/services/session_service.dart';
import '../../models/user_model.dart';
import '../../routes/app_routes.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  final SessionService _sessionService = SessionService();

  final formKey = GlobalKey<FormState>();

  bool obscurePassword = true;
  bool isLoading = false;

  String role = '';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final args = ModalRoute.of(context)?.settings.arguments;

    if (args is String) {
      role = args;
    }
  }

  String get roleTitle {
    switch (role) {
      case AppConstants.customerRole:
        return 'Customer Login';
      case AppConstants.franchiseRole:
        return 'Franchise Login';
      case AppConstants.adminRole:
        return 'Admin Login';
      default:
        return 'Login';
    }
  }

  Future<void> _login() async {
    if (!(formKey.currentState?.validate() ?? false)) {
      return;
    }

    setState(() {
      isLoading = true;
    });

    await Future.delayed(const Duration(milliseconds: 700));

    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    final isValidDemo =
        email.isNotEmpty && password == '123456';

    if (!isValidDemo) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Demo password is 123456',
          ),
        ),
      );

      return;
    }

    final user = UserModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: _getDemoName(),
      email: email,
      role: role,
    );

    await _sessionService.saveUser(user);

    if (!mounted) return;

    setState(() {
      isLoading = false;
    });

    if (role == AppConstants.customerRole) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRoutes.customerDashboard,
        (_) => false,
      );
    } else if (role == AppConstants.franchiseRole) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRoutes.franchiseDashboard,
        (_) => false,
      );
    } else {
      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRoutes.adminDashboard,
        (_) => false,
      );
    }
  }

  String _getDemoName() {
    switch (role) {
      case AppConstants.customerRole:
        return 'Demo Customer';
      case AppConstants.franchiseRole:
        return 'Demo Franchise';
      case AppConstants.adminRole:
        return 'Administrator';
      default:
        return 'User';
    }
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(
                    Icons.arrow_back_rounded,
                  ),
                ),

                const SizedBox(height: 20),

                const CircleAvatar(
                  radius: 34,
                  backgroundColor: Color(0xFFE0F2FE),
                  child: Icon(
                    Icons.water_drop_rounded,
                    size: 38,
                    color: Color(0xFF0284C7),
                  ),
                ),

                const SizedBox(height: 24),

                Text(
                  roleTitle,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0F172A),
                  ),
                ),

                const SizedBox(height: 7),

                const Text(
                  'Enter your account details to continue',
                  style: TextStyle(
                    color: Color(0xFF64748B),
                  ),
                ),

                const SizedBox(height: 32),

                TextFormField(
                  controller: emailController,
                  keyboardType:
                      TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    prefixIcon:
                        Icon(Icons.email_outlined),
                  ),
                  validator: (value) {
                    if (value == null ||
                        value.trim().isEmpty) {
                      return 'Enter your email';
                    }

                    if (!value.contains('@')) {
                      return 'Enter a valid email';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 16),

                TextFormField(
                  controller: passwordController,
                  obscureText: obscurePassword,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon:
                        const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          obscurePassword =
                              !obscurePassword;
                        });
                      },
                      icon: Icon(
                        obscurePassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if (value == null ||
                        value.isEmpty) {
                      return 'Enter password';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 10),

                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Forgot Password?',
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                ElevatedButton(
                  onPressed:
                      isLoading ? null : _login,
                  child: isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text(
                          'Login',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                ),

                const SizedBox(height: 18),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1F5F9),
                    borderRadius:
                        BorderRadius.circular(12),
                  ),
                  child: const Text(
                    'Frontend Demo:\nUse any valid email and password: 123456',
                    style: TextStyle(
                      fontSize: 12,
                      height: 1.5,
                      color: Color(0xFF475569),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}