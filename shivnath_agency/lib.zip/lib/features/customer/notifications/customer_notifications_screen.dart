import 'package:flutter/material.dart';

class CustomerNotificationsScreen extends StatelessWidget {
  const CustomerNotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final notifications = [
      (
        Icons.local_shipping_outlined,
        'Order Dispatched',
        'Your order #ORD1002 has been dispatched.',
        '10 min ago',
      ),
      (
        Icons.check_circle_outline,
        'Order Delivered',
        'Order #ORD1001 was delivered successfully.',
        'Yesterday',
      ),
      (
        Icons.local_offer_outlined,
        'Special Offer',
        'Get free delivery on orders above ₹500.',
        '2 days ago',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notifications',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(18),
        itemCount: notifications.length,
        separatorBuilder: (_, _) =>
            const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final item = notifications[index];

          return Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(14),
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFE0F2FE),
                child: Icon(
                  item.$1,
                  color: const Color(0xFF0284C7),
                ),
              ),
              title: Text(
                item.$2,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Text('${item.$3}\n${item.$4}'),
              ),
            ),
          );
        },
      ),
    );
  }
}