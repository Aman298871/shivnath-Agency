import 'package:flutter/material.dart';

import '../../../core/services/session_service.dart';
import '../../../routes/app_routes.dart';
import '../notifications/customer_notifications_screen.dart';
import '../wallet/customer_wallet_screen.dart';

class CustomerProfileScreen
    extends StatelessWidget {
  const CustomerProfileScreen({
    super.key,
  });

  Future<void> logout(
    BuildContext context,
  ) async {
    await SessionService().logout();

    if (!context.mounted) return;

    Navigator.pushNamedAndRemoveUntil(
      context,
      AppRoutes.roleSelection,
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder:
          (context, constraints) {
        final desktop =
            constraints.maxWidth >= 800;

        if (desktop) {
          return _desktop(context);
        }

        return _mobile(context);
      },
    );
  }

  // ===========================
  // MOBILE
  // ===========================

  Widget _mobile(
    BuildContext context,
  ) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Profile',
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: _profileContent(
        context,
        desktop: false,
      ),
    );
  }

  // ===========================
  // DESKTOP
  // ===========================

  Widget _desktop(
    BuildContext context,
  ) {
    return Container(
      color: const Color(0xFFF8FAFC),
      child: SingleChildScrollView(
        padding:
            const EdgeInsets.all(28),
        child: Center(
          child: ConstrainedBox(
            constraints:
                const BoxConstraints(
              maxWidth: 1100,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'My Profile',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 5),

                const Text(
                  'Manage your account information and preferences.',
                  style: TextStyle(
                    color:
                        Color(0xFF64748B),
                  ),
                ),

                const SizedBox(height: 24),

                Row(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    // LEFT PROFILE
                    Expanded(
                      child: Container(
                        padding:
                            const EdgeInsets.all(
                          24,
                        ),
                        decoration:
                            BoxDecoration(
                          color:
                              Colors.white,
                          borderRadius:
                              BorderRadius.circular(
                            18,
                          ),
                          border:
                              Border.all(
                            color:
                                const Color(
                              0xFFE2E8F0,
                            ),
                          ),
                        ),
                        child: const Column(
                          children: [
                            CircleAvatar(
                              radius: 55,
                              backgroundColor:
                                  Color(
                                0xFFE0F2FE,
                              ),
                              child: Icon(
                                Icons.person,
                                size: 58,
                                color:
                                    Color(
                                  0xFF0284C7,
                                ),
                              ),
                            ),

                            SizedBox(
                              height: 16,
                            ),

                            Text(
                              'Demo Customer',
                              style:
                                  TextStyle(
                                fontSize:
                                    20,
                                fontWeight:
                                    FontWeight
                                        .w800,
                              ),
                            ),

                            SizedBox(
                              height: 5,
                            ),

                            Text(
                              'customer@shivnath.com',
                              style:
                                  TextStyle(
                                color:
                                    Color(
                                  0xFF64748B,
                                ),
                              ),
                            ),

                            SizedBox(
                              height: 8,
                            ),

                            Text(
                              '+91 98765 43210',
                              style:
                                  TextStyle(
                                fontSize:
                                    12,
                                color:
                                    Color(
                                  0xFF64748B,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(
                      width: 22,
                    ),

                    // RIGHT OPTIONS
                    Expanded(
                      flex: 2,
                      child: Column(
                        children: [
                          _ProfileTile(
                            icon: Icons
                                .person_outline,
                            title:
                                'Personal Information',
                            subtitle:
                                'Name, email and mobile number',
                            onTap: () {},
                          ),

                          _ProfileTile(
                            icon: Icons
                                .location_on_outlined,
                            title:
                                'My Addresses',
                            subtitle:
                                'Manage delivery addresses',
                            onTap: () {},
                          ),

                          _ProfileTile(
                            icon: Icons
                                .account_balance_wallet_outlined,
                            title:
                                'My Wallet',
                            subtitle:
                                'Balance and transactions',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      const CustomerWalletScreen(),
                                ),
                              );
                            },
                          ),

                          _ProfileTile(
                            icon: Icons
                                .notifications_none,
                            title:
                                'Notifications',
                            subtitle:
                                'View account updates',
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      const CustomerNotificationsScreen(),
                                ),
                              );
                            },
                          ),

                          _ProfileTile(
                            icon: Icons
                                .settings_outlined,
                            title:
                                'Settings',
                            subtitle:
                                'App preferences',
                            onTap: () {},
                          ),

                          _ProfileTile(
                            icon: Icons
                                .support_agent,
                            title:
                                'Help & Support',
                            subtitle:
                                'Contact customer support',
                            onTap: () {},
                          ),

                          const SizedBox(
                            height: 12,
                          ),

                          SizedBox(
                            width:
                                double.infinity,
                            child:
                                OutlinedButton.icon(
                              onPressed:
                                  () =>
                                      logout(
                                context,
                              ),
                              icon:
                                  const Icon(
                                Icons.logout,
                                color:
                                    Colors.red,
                              ),
                              label:
                                  const Text(
                                'Logout',
                                style:
                                    TextStyle(
                                  color:
                                      Colors.red,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _profileContent(
    BuildContext context, {
    required bool desktop,
  }) {
    return ListView(
      padding:
          const EdgeInsets.all(18),
      children: [
        const CircleAvatar(
          radius: 48,
          backgroundColor:
              Color(0xFFE0F2FE),
          child: Icon(
            Icons.person,
            size: 52,
            color:
                Color(0xFF0284C7),
          ),
        ),

        const SizedBox(height: 12),

        const Center(
          child: Text(
            'Demo Customer',
            style: TextStyle(
              fontSize: 20,
              fontWeight:
                  FontWeight.w800,
            ),
          ),
        ),

        const SizedBox(height: 4),

        const Center(
          child: Text(
            'customer@shivnath.com',
            style: TextStyle(
              color:
                  Color(0xFF64748B),
            ),
          ),
        ),

        const SizedBox(height: 28),

        _ProfileTile(
          icon:
              Icons.person_outline,
          title:
              'Personal Information',
          onTap: () {},
        ),

        _ProfileTile(
          icon: Icons
              .location_on_outlined,
          title:
              'My Addresses',
          onTap: () {},
        ),

        _ProfileTile(
          icon: Icons
              .account_balance_wallet_outlined,
          title: 'My Wallet',
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    const CustomerWalletScreen(),
              ),
            );
          },
        ),

        _ProfileTile(
          icon:
              Icons.notifications_none,
          title: 'Notifications',
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    const CustomerNotificationsScreen(),
              ),
            );
          },
        ),

        _ProfileTile(
          icon:
              Icons.settings_outlined,
          title: 'Settings',
          onTap: () {},
        ),

        _ProfileTile(
          icon:
              Icons.support_agent,
          title: 'Help & Support',
          onTap: () {},
        ),

        const SizedBox(height: 20),

        OutlinedButton.icon(
          onPressed: () =>
              logout(context),
          icon: const Icon(
            Icons.logout,
            color: Colors.red,
          ),
          label: const Text(
            'Logout',
            style:
                TextStyle(
              color: Colors.red,
            ),
          ),
        ),
      ],
    );
  }
}

class _ProfileTile
    extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;

  const _ProfileTile({
    required this.icon,
    required this.title,
    this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin:
          const EdgeInsets.only(
        bottom: 10,
      ),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 5,
        ),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color:
                const Color(0xFFE0F2FE),
            borderRadius:
                BorderRadius.circular(11),
          ),
          child: Icon(
            icon,
            color:
                const Color(0xFF0284C7),
          ),
        ),
        title: Text(
          title,
          style:
              const TextStyle(
            fontWeight:
                FontWeight.w600,
          ),
        ),
        subtitle: subtitle == null
            ? null
            : Text(
                subtitle!,
                style:
                    const TextStyle(
                  fontSize: 10,
                ),
              ),
        trailing:
            const Icon(
          Icons.chevron_right,
        ),
        onTap: onTap,
      ),
    );
  }
}