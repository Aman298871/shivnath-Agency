import 'package:flutter/material.dart';

class FranchiseInvoicesScreen extends StatelessWidget {
  const FranchiseInvoicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final invoices = [
      {
        'id': 'INV-2001',
        'order': 'ORD-1002',
        'date': '02 Sep 2026',
        'total': '₹5,664',
        'paid': '₹0',
        'status': 'Unpaid',
      },
      {
        'id': 'INV-2002',
        'order': 'ORD-1003',
        'date': '02 Sep 2026',
        'total': '₹3,304',
        'paid': '₹1,500',
        'status': 'Partial',
      },
      {
        'id': 'INV-2003',
        'order': 'ORD-0998',
        'date': '28 Aug 2026',
        'total': '₹11,800',
        'paid': '₹11,800',
        'status': 'Paid',
      },
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop = constraints.maxWidth >= 800;

        return Scaffold(
          backgroundColor: const Color(0xFFF6F7FB),
          appBar: desktop
              ? null
              : AppBar(
                  title: const Text('Invoices'),
                ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(desktop ? 28 : 16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(
                  maxWidth: 1200,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (desktop) ...[
                      const Text(
                        'Invoices',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const Text(
                        'View invoices generated against your orders.',
                        style: TextStyle(
                          color: Color(0xFF64748B),
                        ),
                      ),
                      const SizedBox(height: 22),
                    ],

                    ...invoices.map(
                      (invoice) => Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(17),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: const Color(0xFFE5E7EB),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                color: const Color(0xFFEEF2FF),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: const Icon(
                                Icons.receipt_long_rounded,
                                color: Color(0xFF4F46E5),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    invoice['id']!,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  Text(
                                    '${invoice['order']} • ${invoice['date']}',
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF64748B),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (desktop) ...[
                              SizedBox(
                                width: 130,
                                child: Text(invoice['total']!),
                              ),
                              SizedBox(
                                width: 130,
                                child: Text(invoice['paid']!),
                              ),
                            ],
                            _InvoiceStatus(invoice['status']!),
                            const SizedBox(width: 12),
                            IconButton(
                              onPressed: () {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Opening ${invoice['id']}',
                                    ),
                                  ),
                                );
                              },
                              icon: const Icon(
                                Icons.visibility_outlined,
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Invoice download will be connected with backend',
                                    ),
                                  ),
                                );
                              },
                              icon: const Icon(
                                Icons.download_rounded,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _InvoiceStatus extends StatelessWidget {
  final String status;

  const _InvoiceStatus(this.status);

  @override
  Widget build(BuildContext context) {
    Color color = Colors.red;

    if (status == 'Paid') {
      color = Colors.green;
    } else if (status == 'Partial') {
      color = Colors.orange;
    }

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}