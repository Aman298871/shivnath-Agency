import 'package:flutter/material.dart';

class FranchiseNotificationsScreen extends StatelessWidget {
  const FranchiseNotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final notifications = [
      {
        'title': 'Order Approved',
        'message':
            'Your order ORD-1001 has been approved by plant.',
        'time': '10 minutes ago',
        'icon': Icons.check_circle_outline,
      },
      {
        'title': 'Invoice Generated',
        'message':
            'Invoice INV-2001 has been generated.',
        'time': '1 hour ago',
        'icon': Icons.receipt_long_outlined,
      },
      {
        'title': 'Payment Reminder',
        'message':
            '₹5,664 payment is pending against INV-2001.',
        'time': '3 hours ago',
        'icon': Icons.payments_outlined,
      },
      {
        'title': 'Order Dispatched',
        'message':
            'Your order ORD-1003 has been dispatched.',
        'time': 'Yesterday',
        'icon': Icons.local_shipping_outlined,
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: notifications.length,
        separatorBuilder: (_, __) =>
            const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final item = notifications[index];

          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                color: const Color(0xFFE5E7EB),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFFEEF2FF),
                  child: Icon(
                    item['icon'] as IconData,
                    color: const Color(0xFF4F46E5),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        item['title'] as String,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item['message'] as String,
                        style: const TextStyle(
                          color: Color(0xFF64748B),
                          fontSize: 11,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        item['time'] as String,
                        style: const TextStyle(
                          color: Color(0xFF94A3B8),
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}