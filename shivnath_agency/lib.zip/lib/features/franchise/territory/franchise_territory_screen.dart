import 'package:flutter/material.dart';

class FranchiseTerritoryScreen extends StatelessWidget {
  const FranchiseTerritoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop = constraints.maxWidth >= 800;

        return Scaffold(
          backgroundColor: const Color(0xFFF6F7FB),
          appBar: desktop
              ? null
              : AppBar(
                  title: const Text('Territory'),
                ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(desktop ? 28 : 16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(
                  maxWidth: 1050,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (desktop) ...[
                      const Text(
                        'Territory',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const Text(
                        'View your assigned franchise territory.',
                        style: TextStyle(
                          color: Color(0xFF64748B),
                        ),
                      ),
                      const SizedBox(height: 22),
                    ],

                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: const Color(0xFFE5E7EB),
                        ),
                      ),
                      child: const Column(
                        children: [
                          _TerritoryRow(
                            Icons.badge_outlined,
                            'Franchise ID',
                            'FR-1001',
                          ),
                          Divider(),
                          _TerritoryRow(
                            Icons.location_city_outlined,
                            'City',
                            'Raipur',
                          ),
                          Divider(),
                          _TerritoryRow(
                            Icons.map_outlined,
                            'District',
                            'Raipur',
                          ),
                          Divider(),
                          _TerritoryRow(
                            Icons.pin_drop_outlined,
                            'State',
                            'Chhattisgarh',
                          ),
                          Divider(),
                          _TerritoryRow(
                            Icons.location_on_outlined,
                            'Assigned Area',
                            'Raipur Urban Zone',
                          ),
                          Divider(),
                          _TerritoryRow(
                            Icons.check_circle_outline,
                            'Status',
                            'Active',
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    Container(
                      width: double.infinity,
                      height: 280,
                      decoration: BoxDecoration(
                        color: const Color(0xFFEEF2FF),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.map_rounded,
                            size: 70,
                            color: Color(0xFF4F46E5),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Territory Map',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'Google Maps integration will appear here',
                            style: TextStyle(
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _TerritoryRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _TerritoryRow(
    this.icon,
    this.title,
    this.value,
  );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Icon(
            icon,
            color: const Color(0xFF4F46E5),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Color(0xFF64748B),
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}