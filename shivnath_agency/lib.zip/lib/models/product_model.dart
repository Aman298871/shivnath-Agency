class ProductModel {
  final String id;
  final String name;
  final String category;
  final String size;
  final double price;
  final String unit;
  final String image;
  final int stock;
  final String description;

  const ProductModel({
    required this.id,
    required this.name,
    required this.category,
    required this.size,
    required this.price,
    required this.unit,
    required this.image,
    required this.stock,
    required this.description,
  });
}