import 'package:flutter/material.dart';

import '../features/admin/admin_main_screen.dart';
import '../features/auth/login_screen.dart';
import '../features/auth/role_selection_screen.dart';
import '../features/auth/splash_screen.dart';

import '../features/customer/customer_main_screen.dart';
import '../features/franchise/franchise_main_screen.dart';

class AppRoutes {
  static const String splash = '/';
  static const String roleSelection = '/role-selection';
  static const String login = '/login';

  static const String customerDashboard =
      '/customer/dashboard';

  static const String franchiseDashboard =
      '/franchise/dashboard';

  static const String adminDashboard =
      '/admin/dashboard';

  static Route<dynamic> generateRoute(
    RouteSettings settings,
  ) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(
          builder: (_) => const SplashScreen(),
          settings: settings,
        );

      case roleSelection:
        return MaterialPageRoute(
          builder: (_) => const RoleSelectionScreen(),
          settings: settings,
        );

      case login:
        return MaterialPageRoute(
          builder: (_) => const LoginScreen(),
          settings: settings,
        );

      case customerDashboard:
        return MaterialPageRoute(
          builder: (_) => const CustomerMainScreen(),
          settings: settings,
        );

      case franchiseDashboard:
        return MaterialPageRoute(
          builder: (_) => const FranchiseMainScreen(),
          settings: settings,
        );

      case adminDashboard:
        return MaterialPageRoute(
          builder: (_) => const AdminMainScreen(),
          settings: settings,
        );

      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(
              child: Text('Page not found'),
            ),
          ),
          settings: settings,
        );
    }
  }
}